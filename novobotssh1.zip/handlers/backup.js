const fs = require('fs');
const path = require('path');

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  const fileUsuarios = path.join(__dirname, '../data/usuarios.json');
  const backupPath = path.join(__dirname, '../data/backup.vps');

  if (!fs.existsSync(fileUsuarios)) {
    return bot.sendMessage(chatId, '❌ Arquivo de usuários não encontrado para backup.', menuPrincipal);
  }

  try {
    const data = fs.readFileSync(fileUsuarios, 'utf8');
    fs.writeFileSync(backupPath, data, 'utf8');

    bot.sendDocument(chatId, backupPath, {
      caption: '📦 Backup dos usuários (backup.vps)',
      ...menuPrincipal.reply_markup ? {reply_markup: menuPrincipal.reply_markup} : {}
    });

  } catch (err) {
    console.error('Erro ao criar/enviar backup:', err);
    bot.sendMessage(chatId, '❌ Falha ao criar o backup dos usuários.', menuPrincipal);
  }
};
