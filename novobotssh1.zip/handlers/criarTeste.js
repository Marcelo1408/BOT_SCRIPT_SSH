const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;

  estados[chatId] = { etapa: 'horas' };
  bot.sendMessage(chatId, '⏳ Informe o tempo de teste (em horas):');

  bot.once('message', (resposta) => {
    if (!estados[chatId] || resposta.chat.id !== chatId) return;

    const horas = parseInt(resposta.text, 10);
    if (isNaN(horas) || horas <= 0) {
      bot.sendMessage(chatId, '❌ Quantidade de horas inválida. Operação cancelada.', menuPrincipal);
      delete estados[chatId];
      return;
    }

    // Gerar usuário e senha aleatórios
    const numero = Math.floor(1000 + Math.random() * 9000);
    const username = `teste${numero}`;
    const senha = username;

    // Data de expiração (hora certa)
    const dataExpiracao = new Date(Date.now() + horas * 3600000);
    const dataFormatada = dataExpiracao.toLocaleString('pt-BR');

    (async () => {
      try {
        const ssh = await conexaoSSH();

        const comando = `
sudo useradd -m -s /bin/bash ${username} &&
echo "${username}:${senha}" | sudo chpasswd &&
echo "${username} hard maxlogins 1" | sudo tee -a /etc/security/limits.conf &&
echo "sudo userdel -r ${username}" | sudo at now + ${horas} hours
        `;

        await ssh.execCommand(comando);
        ssh.dispose();

        // Atualiza o arquivo local
        const usuariosPath = path.join(__dirname, '../data/usuarios.json');
        const usuarios = fs.existsSync(usuariosPath)
          ? JSON.parse(fs.readFileSync(usuariosPath))
          : [];

        usuarios.push({
          username: username,
          senha: senha,
          data_criacao: new Date().toISOString(),
          expira_em: dataExpiracao.toISOString(),
          limite_conexoes: 1
        });

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        bot.sendMessage(
          chatId,
          `🎉 *Teste criado com sucesso!*\n\n` +
          `👤: \`${username}\`\n` +
          `🔑: \`${senha}\`\n` +
          `⏳ Validade: ${horas} horas\n` +
          `📅 Expira em: ${dataFormatada}\n` +
          `🔌 Limite: 1 conexão`,
          { parse_mode: 'Markdown', ...menuPrincipal }
        );

      } catch (error) {
        bot.sendMessage(
          chatId,
          `❌ Falha ao criar teste:\n\n${error.message}`,
          menuPrincipal
        );
      } finally {
        delete estados[chatId];
      }
    })();
  });
};

