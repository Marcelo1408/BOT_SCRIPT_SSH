const { NodeSSH } = require('node-ssh');
require('dotenv').config(); // Carrega variáveis do .env

const ssh = new NodeSSH();

async function conectarSSH() {
  try {
    // Valida variáveis obrigatórias do .env
    const requiredVars = ['SERVER_HOST', 'SERVER_USER', 'SERVER_PASSWORD'];
    const missingVars = requiredVars.filter(v => !process.env[v]);

    if (missingVars.length > 0) {
      throw new Error(`Variáveis faltando no .env: ${missingVars.join(', ')}`);
    }

    // Conexão SSH usando dados do .env
    await ssh.connect({
      host: process.env.SERVER_HOST,
      username: process.env.SERVER_USER,
      password: process.env.SERVER_PASSWORD,
      port: process.env.SERVER_PORT || 22, // Porta padrão 22 se não definida
    });

    console.log(`✅ Conectado ao servidor ${process.env.SERVER_HOST}:${process.env.SERVER_PORT || 22}`);
    return ssh;

  } catch (error) {
    console.error('❌ Falha na conexão SSH:', error.message);
    throw error; // Propaga o erro para quem chamar a função
  }
}

module.exports = conectarSSH;