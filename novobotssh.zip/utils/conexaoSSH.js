const { NodeSSH } = require('node-ssh');
require('dotenv').config();

class ConexaoSSH {
  constructor() {
    this.ssh = new NodeSSH();
    this.timeout = parseInt(process.env.SSH_TIMEOUT) || 10000; // Timeout opcional via .env
  }

  /**
   * Conecta ao servidor SSH usando as variáveis do .env
   * @returns {Promise<NodeSSH>} Instância da conexão SSH
   */
  async conectar() {
    try {
      const { SERVER_HOST, SERVER_USER, SERVER_PASSWORD, SERVER_PORT } = process.env;
      if (!SERVER_HOST || !SERVER_USER || !SERVER_PASSWORD) {
        throw new Error('Variáveis de ambiente SSH ausentes ou inválidas.');
      }

      await this.ssh.connect({
        host: SERVER_HOST,
        username: SERVER_USER,
        password: SERVER_PASSWORD,
        port: parseInt(SERVER_PORT) || 22,
        readyTimeout: this.timeout,
        tryKeyboard: true
      });

      console.log(`✅ Conectado via SSH em ${SERVER_HOST}:${SERVER_PORT || 22}`);
      return this.ssh;
    } catch (error) {
      console.error('❌ Erro na conexão SSH:', error.message);
      throw new Error(`Falha na conexão SSH: ${error.message}`);
    }
  }

  /**
   * Cria um usuário no servidor SSH
   * @param {string} username - Nome do usuário
   * @param {string} password - Senha do usuário
   * @param {string} expiryDate - Data de expiração no formato YYYY-MM-DD
   * @param {number} [limit=1] - Limite de conexões simultâneas
   * @returns {Promise<boolean>}
   */
  async criarUsuario(username, password, expiryDate, limit = 1) {
    let connection;
    try {
      if (!username || !password) throw new Error('Username e senha obrigatórios.');

      connection = await this.conectar();

      let formattedDate;
      try {
        const dateObj = new Date(expiryDate);
        if (isNaN(dateObj.getTime())) throw new Error('Data inválida.');
        formattedDate = dateObj.toISOString().split('T')[0];
      } catch {
        const defaultDate = new Date();
        defaultDate.setDate(defaultDate.getDate() + 30);
        formattedDate = defaultDate.toISOString().split('T')[0];
        console.warn(`⚠️ Usando data padrão para ${username}: ${formattedDate}`);
      }

      const commands = [
        `sudo useradd -m -s /bin/bash ${username}`,
        `echo "${username}:${password}" | sudo chpasswd`,
        `sudo usermod -e ${formattedDate} ${username}`,
        `sudo bash -c 'echo "* hard maxlogins ${limit}" >> /etc/security/limits.conf'`,
        `sudo bash -c 'echo "* soft maxlogins ${limit}" >> /etc/security/limits.conf'`
      ];

      for (const cmd of commands) {
        const result = await connection.execCommand(cmd);
        if (result.stderr && !result.stderr.includes('already exists')) {
          throw new Error(result.stderr);
        }
      }

      const checkUser = await connection.execCommand(`id ${username}`);
      if (checkUser.stderr) throw new Error('Falha ao verificar usuário criado.');

      console.log(`✅ Usuário ${username} criado com sucesso.`);
      return true;
    } catch (error) {
      console.error(`❌ Erro ao criar usuário ${username}:`, error.message);
      throw error;
    } finally {
      if (connection) await connection.dispose();
    }
  }

  /**
   * Verifica se um usuário existe no servidor
   * @param {string} username 
   * @returns {Promise<boolean>}
   */
  async usuarioExiste(username) {
    let connection;
    try {
      connection = await this.conectar();
      const result = await connection.execCommand(`id ${username}`);
      return !result.stderr;
    } catch (error) {
      console.error(`❌ Erro ao verificar usuário ${username}:`, error.message);
      throw error;
    } finally {
      if (connection) await connection.dispose();
    }
  }

  /**
   * Encerra a conexão SSH
   */
  async desconectar() {
    try {
      await this.ssh.dispose();
      console.log('✅ Conexão SSH encerrada.');
    } catch (error) {
      console.error('❌ Erro ao encerrar SSH:', error.message);
    }
  }

  /**
   * Executa um comando remoto via SSH
   * @param {string} comando
   * @returns {Promise<Object>} Resultado do comando
   */
  async executarComando(comando) {
    const connection = await this.conectar();
    try {
      return await connection.execCommand(comando);
    } finally {
      await connection.dispose();
    }
  }
}

module.exports = ConexaoSSH;
