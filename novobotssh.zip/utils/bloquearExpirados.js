const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Caminho do arquivo de usuários
const usuariosPath = path.join(__dirname, '../data/usuarios.json');

// Função para bloquear usuário
function bloquearUsuario(username) {
  // Aqui você coloca o comando real de SSH ou outra lógica
  console.log(`Bloqueando usuário: ${username}`);
  // Exemplo: exec(`ssh root@IP 'pkill -u ${username}'`);
}

// Função para verificar expirados
function verificarExpirados() {
  if (!fs.existsSync(usuariosPath)) {
    console.log('Arquivo usuarios.json não encontrado.');
    return;
  }

  const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
  const agora = new Date();

  usuarios.forEach(user => {
    const expiraEm = new Date(user.expira_em);

    if (expiraEm <= agora && !user.bloqueado) {
      console.log(`Usuário expirado: ${user.username}`);

      // Bloqueia usuário
      bloquearUsuario(user.username);

      // Atualiza status
      user.bloqueado = true;
    }
  });

  // Salva de volta
  fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
  console.log('Verificação finalizada.');
}

// Executa a verificação
verificarExpirados();

