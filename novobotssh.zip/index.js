require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

// =============================================
// 1. CONFIGURAÇÃO INICIAL
// =============================================

// Verificar variáveis de ambiente obrigatórias
const requiredEnvVars = ['BOT_TOKEN', 'ADM_ID', 'SERVER_HOST', 'SERVER_USER', 'SERVER_PASSWORD'];
const missingVars = requiredEnvVars.filter(v => !process.env[v]);

if (missingVars.length > 0) {
  console.error(`❌ Variáveis de ambiente ausentes: ${missingVars.join(', ')}`);
  process.exit(1);
}

// Configurar arquivos de dados
const ensureDataFiles = () => {
  const dataDir = path.join(__dirname, 'data');
  const usersFile = path.join(dataDir, 'usuarios.json');
  const backupsDir = path.join(__dirname, 'backups');

  try {
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');
    if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
  } catch (err) {
    console.error('❌ Erro ao configurar arquivos de dados:', err);
    process.exit(1);
  }
};
ensureDataFiles();

// =============================================
// 2. CONTROLE DE INSTÂNCIA ÚNICA
// =============================================

const LOCK_FILE = path.join(__dirname, 'bot.lock');

const handleLockFile = () => {
  try {
    if (fs.existsSync(LOCK_FILE)) {
      const pid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8'));
      try {
        process.kill(pid, 0);
        console.error(`❌ Bot já está em execução (PID: ${pid})`);
        process.exit(1);
      } catch {
        fs.unlinkSync(LOCK_FILE);
      }
    }
    fs.writeFileSync(LOCK_FILE, String(process.pid));
  } catch (err) {
    console.error('❌ Erro no controle de instância:', err);
    process.exit(1);
  }
};
handleLockFile();

// =============================================
// 3. INICIALIZAÇÃO DO BOT
// =============================================

const initBot = () => {
  try {
    const bot = new TelegramBot(process.env.BOT_TOKEN, {
      polling: {
        interval: 3000,
        params: {
          timeout: 30,
          allowed_updates: ['message', 'callback_query']
        }
      },
      request: { timeout: 60000 }
    });

    bot.on('polling_error', (error) => {
      console.error('⚠️ Erro no polling:', error.message);
      if (error.code === 'EFATAL') {
        console.error('❌ Erro fatal, reiniciando...');
        setTimeout(() => process.exit(1), 5000);
      }
    });

    bot.setMyCommands([
      { command: 'start', description: 'Iniciar o bot' },
      { command: 'menu', description: 'Mostrar menu principal' }
    ]);

    return bot;
  } catch (err) {
    console.error('❌ Falha ao criar instância do bot:', err);
    process.exit(1);
  }
};

const bot = initBot();

// =============================================
// 4. FUNÇÕES AUXILIARES
// =============================================

const carregarUsuarios = () => {
  const usuariosPath = path.join(__dirname, 'data', 'usuarios.json');
  try {
    return JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
  } catch (err) {
    console.error('Erro ao carregar usuários:', err);
    return [];
  }
};

const isAdmin = (msg) => msg.from?.id.toString() === process.env.ADM_ID;

const editOrSendMessage = async (bot, chatId, messageId, text, options = {}) => {
  try {
    if (messageId) {
      return await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'Markdown',
        ...options
      });
    }
    return await bot.sendMessage(chatId, text, {
      parse_mode: 'Markdown',
      ...options
    });
  } catch (err) {
    if (err.message.includes('message is not modified') || err.message.includes('message to edit not found')) {
      return await bot.sendMessage(chatId, text, {
        parse_mode: 'Markdown',
        ...options
      });
    }
    throw err;
  }
};

// =============================================
// 5. MENUS INTERATIVOS
// =============================================

const menuPrincipal = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '🟢 Onlines', callback_data: '🟢 Onlines' }],
      [{ text: '📦 Menu Servidores', callback_data: 'menu_servidores' }],
      [{ text: '👤 Menu Usuários', callback_data: 'menu_usuarios' }],
      [{ text: '🔄 Menu Backups', callback_data: 'menu_backups' }],
    ],
  },
  parse_mode: 'Markdown'
};

const menuServidores = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '📊 Add Servidor', callback_data: '📊 Add Servidor' }],
      [{ text: '📋 Listar Servidores', callback_data: '📋 Listar Servidores' }],
      [{ text: '🗑️ Excluir Servidor', callback_data: '🗑️ Excluir Servidor' }],
      [{ text: '⬅️ Voltar', callback_data: 'voltar_menu_principal' }],
    ],
  },
  parse_mode: 'Markdown'
};

const menuUsuarios = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '👤 Criar Usuário', callback_data: '👤 Criar Usuário' }],
      [{ text: '📝 Criar Teste', callback_data: '📝 Criar Teste' }],
      [{ text: '🔑 Alterar Senha', callback_data: '🔑 Alterar Senha' }],
      [{ text: '🔌 Alterar Limite', callback_data: '🔌 Alterar Limite' }],
      [{ text: '📅 Alterar Data', callback_data: '📅 Alterar Data' }],
      [{ text: '⏳ Expirados', callback_data: '⏳ Expirados' }],
      [{ text: '📃 Info. de Usuários', callback_data: '📃 Info. de Usuários' }],
      [{ text: '❌ Remover', callback_data: '❌ Remover' }],
      [{ text: '⬅️ Voltar', callback_data: 'voltar_menu_principal' }],
    ],
  },
  parse_mode: 'Markdown'
};

const menuBackups = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '📦 Backup', callback_data: '📦 Backup' }],
      [{ text: '📤 Upload Backup', callback_data: '📤 Upload Backup' }],
      [{ text: '📥 Restaurar Backup', callback_data: '📥 Restaurar Backup' }],
      [{ text: '⬅️ Voltar', callback_data: 'voltar_menu_principal' }],
    ],
  },
  parse_mode: 'Markdown'
};

const exibirMenuPrincipal = (chatId, messageId = null) => {
  const mensagemMenu = `
=*==*==*==*==*==*==*==*==*==*==*=*==*=*==*=*==*= 
  *BEM VINDO AO GERENCIADOR DO SERVIDOR VPN* 
=*==*==*==*==*==*==*==*==*==*==*=*==*=*==*=*==*= 

⚠️ *SELECIONE UMA OPÇÃO ABAIXO!*
`;

  if (messageId) {
    return bot.editMessageText(mensagemMenu, {
      chat_id: chatId,
      message_id: messageId,
      ...menuPrincipal
    }).catch(err => {
      console.log('Erro ao editar mensagem, enviando nova:', err.message);
      bot.sendMessage(chatId, mensagemMenu, menuPrincipal);
    });
  }
  return bot.sendMessage(chatId, mensagemMenu, menuPrincipal);
};

const exibirMenuServidores = (chatId, messageId) => {
  bot.editMessageText('📦 *MENU SERVIDORES* - Selecione uma opção:', {
    chat_id: chatId,
    message_id: messageId,
    ...menuServidores
  }).catch(err => {
    console.log('Erro ao editar mensagem:', err.message);
    bot.sendMessage(chatId, '📦 *MENU SERVIDORES* - Selecione uma opção:', menuServidores);
  });
};

const exibirMenuUsuarios = (chatId, messageId) => {
  bot.editMessageText('👤 *MENU USUÁRIOS* - Selecione uma opção:', {
    chat_id: chatId,
    message_id: messageId,
    ...menuUsuarios
  }).catch(err => {
    console.log('Erro ao editar mensagem:', err.message);
    bot.sendMessage(chatId, '👤 *MENU USUÁRIOS* - Selecione uma opção:', menuUsuarios);
  });
};

const exibirMenuBackups = (chatId, messageId) => {
  bot.editMessageText('🔄 *MENU BACKUPS* - Selecione uma opção:', {
    chat_id: chatId,
    message_id: messageId,
    ...menuBackups
  }).catch(err => {
    console.log('Erro ao editar mensagem:', err.message);
    bot.sendMessage(chatId, '🔄 *MENU BACKUPS* - Selecione uma opção:', menuBackups);
  });
};

// =============================================
// 6. HANDLERS
// =============================================

const loadHandler = (handlerName) => {
  const handlerPath = path.join(__dirname, 'handlers', `${handlerName}.js`);
  try {
    fs.accessSync(handlerPath);
    delete require.cache[require.resolve(handlerPath)];
    const handler = require(handlerPath);
    if (typeof handler !== 'function') throw new Error('Exportação inválida');
    console.log(`✅ Handler ${handlerName} carregado`);
    return handler;
  } catch (err) {
    console.error(`❌ Falha ao carregar ${handlerName}: ${err.message}`);
    return (bot, msg) => {
      bot.sendMessage(msg.chat.id, `⚠️ Comando indisponível\nErro: ${err.message}`, { parse_mode: 'Markdown' });
    };
  }
};

const initHandlers = () => {
  const handlerMap = {
    '👤 Criar Usuário': 'criarUsuario',
    '📝 Criar Teste': 'criarTeste',
    '❌ Remover': 'removerUsuario',
    '🔑 Alterar Senha': 'alterarSenha',
    '📊 Add Servidor': 'addServidor',
    '📋 Listar Servidores': 'listarServidores',
    '🗑️ Excluir Servidor': 'excluirServidor',
    '📅 Alterar Data': 'alterarData',
    '🟢 Onlines': 'onlines',
    '⏳ Expirados': 'expirados',
    '📦 Backup': 'backup',
    '🔌 Alterar Limite': 'alterarLimite',
    '📤 Upload Backup': 'uploadBackup',
    '📥 Restaurar Backup': 'restaurarBackup',
    '📃 Info. de Usuários': 'informacoes'
  };

  const handlers = {};
  for (const [command, handlerName] of Object.entries(handlerMap)) {
    handlers[command] = loadHandler(handlerName);
  }
  return handlers;
};

const handlers = initHandlers();

// =============================================
// 7. LÓGICA PRINCIPAL DO BOT
// =============================================

bot.onText(/\/start|\/menu/, (msg) => {
  if (!isAdmin(msg)) return bot.sendMessage(msg.chat.id, '🔒 Acesso restrito');
  exibirMenuPrincipal(msg.chat.id);
});

bot.on('callback_query', async (callbackQuery) => {
  const action = callbackQuery.data;
  const msg = callbackQuery.message;

  if (!isAdmin(callbackQuery)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: '🔒 Acesso restrito!' });
  }

  switch(action) {
    case 'menu_servidores':
      await exibirMenuServidores(msg.chat.id, msg.message_id);
      break;
    case 'menu_usuarios':
      await exibirMenuUsuarios(msg.chat.id, msg.message_id);
      break;
    case 'menu_backups':
      await exibirMenuBackups(msg.chat.id, msg.message_id);
      break;
    case 'voltar_menu_principal':
      await exibirMenuPrincipal(msg.chat.id, msg.message_id);
      break;
    default:
      const handler = handlers[action];
      if (handler) {
        try {
          await handler(bot, msg, {
            messageId: msg.message_id,
            editOrSendMessage: editOrSendMessage,
            chatId: msg.chat.id
          });
        } catch (err) {
          console.error(`Erro no handler ${action}:`, err);
          await editOrSendMessage(bot, msg.chat.id, msg.message_id, 
            '❌ Erro interno. Tente novamente.', menuPrincipal);
        }
      }
  }

  await bot.answerCallbackQuery(callbackQuery.id);
});

// =============================================
// 8. ENCERRAMENTO SEGURO
// =============================================

const gracefulShutdown = async () => {
  console.log('\n🛑 Encerrando o bot...');
  try {
    if (bot && bot.stopPolling) await bot.stopPolling();
    if (fs.existsSync(LOCK_FILE)) fs.unlinkSync(LOCK_FILE);
    console.log('✅ Bot encerrado corretamente');
    process.exit(0);
  } catch (err) {
    console.error('❌ Erro no encerramento:', err);
    process.exit(1);
  }
};

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
process.on('uncaughtException', (err) => {
  console.error('💥 Erro não tratado:', err);
  gracefulShutdown();
});

console.log('✅ Bot iniciado com sucesso');