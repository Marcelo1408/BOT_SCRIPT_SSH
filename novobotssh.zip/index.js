require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

// =============================================
// 1. CONFIGURAÇÃO INICIAL ROBUSTA
// =============================================

// Verificação de variáveis de ambiente essenciais
const requiredEnvVars = ['BOT_TOKEN', 'ADM_ID', 'SERVER_HOST', 'SERVER_USER', 'SERVER_PASSWORD'];
const missingVars = requiredEnvVars.filter(v => !process.env[v]);

if (missingVars.length > 0) {
  console.error(`❌ Variáveis de ambiente ausentes: ${missingVars.join(', ')}`);
  process.exit(1);
}

// Configuração de diretórios e arquivos essenciais
const ensureDataFiles = () => {
  const dataDir = path.join(__dirname, 'data');
  const usersFile = path.join(dataDir, 'usuarios.json');
  const backupsDir = path.join(__dirname, 'backups');

  try {
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');
    if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
  } catch (err) {
    console.error('❌ Erro ao configurar arquivos de dados:', err);
    process.exit(1);
  }
};
ensureDataFiles();

// =============================================
// 2. CONTROLE DE INSTÂNCIA ÚNICA MELHORADO
// =============================================

const LOCK_FILE = path.join(__dirname, 'bot.lock');

const handleLockFile = () => {
  try {
    if (fs.existsSync(LOCK_FILE)) {
      const pid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8'));
      try {
        process.kill(pid, 0);
        console.error(`❌ Bot já está em execução (PID: ${pid})`);
        process.exit(1);
      } catch {
        fs.unlinkSync(LOCK_FILE);
      }
    }
    fs.writeFileSync(LOCK_FILE, String(process.pid));
  } catch (err) {
    console.error('❌ Erro no controle de instância:', err);
    process.exit(1);
  }
};
handleLockFile();

// =============================================
// 3. INICIALIZAÇÃO DO BOT COM TRATAMENTO DE ERROS
// =============================================

const initBot = () => {
  try {
    const bot = new TelegramBot(process.env.BOT_TOKEN, {
      polling: {
        interval: 3000,
        params: {
          timeout: 30,
          allowed_updates: ['message', 'callback_query']
        }
      },
      request: {
        timeout: 60000
      }
    });

    bot.on('polling_error', (error) => {
      console.error('⚠️ Erro no polling:', error.message);
      if (error.code === 'EFATAL') {
        console.error('❌ Erro fatal no polling, reiniciando...');
        setTimeout(() => process.exit(1), 5000);
      }
    });

    return bot;
  } catch (err) {
    console.error('❌ Falha ao criar instância do bot:', err);
    process.exit(1);
  }
};

const bot = initBot();

// =============================================
// 4. SISTEMA DE HANDLERS COM RECUPERAÇÃO DE FALHAS
// =============================================

const loadHandler = (handlerName) => {
  const handlerPath = path.join(__dirname, 'handlers', `${handlerName}.js`);
  
  try {
    fs.accessSync(handlerPath);
    delete require.cache[require.resolve(handlerPath)];
    const handler = require(handlerPath);
    
    if (typeof handler !== 'function') {
      throw new Error('Exportação inválida - não é uma função');
    }

    console.log(`✅ Handler ${handlerName} carregado`);
    return handler;
  } catch (err) {
    console.error(`❌ Falha ao carregar ${handlerName}:`, err.message);
    return (bot, msg) => {
      bot.sendMessage(
        msg.chat.id,
        `⚠️ Comando temporariamente indisponível\nErro: ${err.message}`,
        { parse_mode: 'Markdown' }
      );
    };
  }
};

const initHandlers = () => {
  const handlerMap = {
    '👤 Criar Usuário': 'criarUsuario',
    '📝 Criar Teste': 'criarTeste',
    '❌ Remover': 'removerUsuario',
    '🔑 Alterar Senha': 'alterarSenha',
    '📊 Add Servidor': 'addServidor',
    '📋 Listar Servidores': 'listarServidores',
    '🗑️ Excluir Servidor': 'excluirServidor',
    '📅 Alterar Data': 'alterarData',
    '🟢 Onlines': 'onlines',
    '⏳ Expirados': 'expirados',
    '📦 Backup': 'backup',
    '🔌 Alterar Limite': 'alterarLimite',
    '📤 Upload Backup': 'uploadBackup',
    '📥 Restaurar Backup': 'restaurarBackup'
  };

  const handlers = {};
  for (const [command, handlerName] of Object.entries(handlerMap)) {
    handlers[command] = loadHandler(handlerName);
  }

  // Handler especial para informações
  try {
    const conexaoSSH = require('./utils/conexaoSSH');
    handlers['📃 Info. de Usuários'] = require('./handlers/informacoes')(conexaoSSH);
    console.log('✅ Handler de informações carregado');
  } catch (err) {
    console.error('❌ Erro no handler de informações:', err);
    handlers['📃 Info. de Usuários'] = (bot, msg) => {
      bot.sendMessage(msg.chat.id, '⚠️ Serviço de informações indisponível', { parse_mode: 'Markdown' });
    };
  }

  return handlers;
};

const handlers = initHandlers();

// =============================================
// 5. CONFIGURAÇÃO DO MENU PRINCIPAL
// =============================================

const menuPrincipal = {
  reply_markup: {
    keyboard: [
      ['🟢 Onlines'],
      ['📊 Add Servidor', '📋 Listar Servidores'],
      ['🗑️ Excluir Servidor', '⏳ Expirados'],
      ['👤 Criar Usuário', '📝 Criar Teste'],
      ['🔑 Alterar Senha','🔌 Alterar Limite'],
      [ '📅 Alterar Data','📃 Info. de Usuários'],
      ['❌ Remover','📦 Backup'],
      ['📤 Upload Backup', '📥 Restaurar Backup']
      
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  },
  parse_mode: 'Markdown'
};

// =============================================
// 6. LÓGICA PRINCIPAL DO BOT
// =============================================

const isAdmin = (msg) => msg.from?.id.toString() === process.env.ADM_ID;

bot.onText(/\/start/, (msg) => {
  if (!isAdmin(msg)) {
    return bot.sendMessage(msg.chat.id, '🔒 Acesso restrito ao administrador');
  }
  bot.sendMessage(msg.chat.id, '🤖 *Bot SSH Manager* - Pronto para uso', menuPrincipal);
});

bot.on('message', async (msg) => {
  if (!msg.text || !isAdmin(msg)) return;

  const handler = handlers[msg.text];
  if (handler) {
    try {
      console.log(`Executando handler para: ${msg.text}`);
      await handler(bot, msg, menuPrincipal);
    } catch (err) {
      console.error(`Erro no handler ${msg.text}:`, err);
      await bot.sendMessage(
        msg.chat.id,
        '❌ Ocorreu um erro ao processar seu comando',
        menuPrincipal
      );
    }
  }
});

// =============================================
// 7. GERENCIAMENTO DE ENCERRAMENTO
// =============================================

const gracefulShutdown = async () => {
  console.log('\n🛑 Encerrando o bot...');
  try {
    if (bot && bot.stopPolling) {
      await bot.stopPolling();
    }
    if (fs.existsSync(LOCK_FILE)) {
      fs.unlinkSync(LOCK_FILE);
    }
    console.log('✅ Bot encerrado corretamente');
    process.exit(0);
  } catch (err) {
    console.error('❌ Erro durante o encerramento:', err);
    process.exit(1);
  }
};

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
process.on('uncaughtException', (err) => {
  console.error('💥 Erro não tratado:', err);
  gracefulShutdown();
});

console.log('✅ Bot iniciado com sucesso');
