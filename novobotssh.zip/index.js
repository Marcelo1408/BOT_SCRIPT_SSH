require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

// =============================================
// 1. CONFIGURAÇÃO INICIAL ROBUSTA
// =============================================

const requiredEnvVars = ['BOT_TOKEN', 'ADM_ID', 'SERVER_HOST', 'SERVER_USER', 'SERVER_PASSWORD'];
const missingVars = requiredEnvVars.filter(v => !process.env[v]);

if (missingVars.length > 0) {
  console.error(`❌ Variáveis de ambiente ausentes: ${missingVars.join(', ')}`);
  process.exit(1);
}

const ensureDataFiles = () => {
  const dataDir = path.join(__dirname, 'data');
  const usersFile = path.join(dataDir, 'usuarios.json');
  const backupsDir = path.join(__dirname, 'backups');

  try {
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');
    if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
  } catch (err) {
    console.error('❌ Erro ao configurar arquivos de dados:', err);
    process.exit(1);
  }
};
ensureDataFiles();

// =============================================
// 2. CONTROLE DE INSTÂNCIA ÚNICA
// =============================================

const LOCK_FILE = path.join(__dirname, 'bot.lock');

const handleLockFile = () => {
  try {
    if (fs.existsSync(LOCK_FILE)) {
      const pid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8'));
      try {
        process.kill(pid, 0);
        console.error(`❌ Bot já está em execução (PID: ${pid})`);
        process.exit(1);
      } catch {
        fs.unlinkSync(LOCK_FILE);
      }
    }
    fs.writeFileSync(LOCK_FILE, String(process.pid));
  } catch (err) {
    console.error('❌ Erro no controle de instância:', err);
    process.exit(1);
  }
};
handleLockFile();

// =============================================
// 3. INICIALIZAÇÃO DO BOT
// =============================================

const initBot = () => {
  try {
    const bot = new TelegramBot(process.env.BOT_TOKEN, {
      polling: {
        interval: 3000,
        params: {
          timeout: 30,
          allowed_updates: ['message', 'callback_query']
        }
      },
      request: { timeout: 60000 }
    });

    bot.on('polling_error', (error) => {
      console.error('⚠️ Erro no polling:', error.message);
      if (error.code === 'EFATAL') {
        console.error('❌ Erro fatal, reiniciando...');
        setTimeout(() => process.exit(1), 5000);
      }
    });

    bot.setMyCommands([
      { command: 'start', description: 'Iniciar o bot e mostrar o menu' },
      { command: 'menu', description: 'Mostrar o menu novamente' }
    ]);

    return bot;
  } catch (err) {
    console.error('❌ Falha ao criar instância do bot:', err);
    process.exit(1);
  }
};

const bot = initBot();

// =============================================
// 4. FUNÇÕES AUXILIARES
// =============================================

const carregarUsuarios = () => {
  const usuariosPath = path.join(__dirname, 'data', 'usuarios.json');
  try {
    return JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
  } catch (err) {
    console.error('Erro ao carregar usuários:', err);
    return [];
  }
};

const isAdmin = (msg) => msg.from?.id.toString() === process.env.ADM_ID;

// =============================================
// 5. HANDLERS
// =============================================

const loadHandler = (handlerName) => {
  const handlerPath = path.join(__dirname, 'handlers', `${handlerName}.js`);
  try {
    fs.accessSync(handlerPath);
    delete require.cache[require.resolve(handlerPath)];
    const handler = require(handlerPath);
    if (typeof handler !== 'function') throw new Error('Exportação inválida');
    console.log(`✅ Handler ${handlerName} carregado`);
    return handler;
  } catch (err) {
    console.error(`❌ Falha ao carregar ${handlerName}: ${err.message}`);
    return (bot, msg) => {
      bot.sendMessage(msg.chat.id, `⚠️ Comando indisponível\nErro: ${err.message}`, { parse_mode: 'Markdown' });
    };
  }
};

const initHandlers = () => {
  const handlerMap = {
    '👤 Criar Usuário': 'criarUsuario',
    '📝 Criar Teste': 'criarTeste',
    '❌ Remover': 'removerUsuario',
    '🔑 Alterar Senha': 'alterarSenha',
    '📊 Add Servidor': 'addServidor',
    '📋 Listar Servidores': 'listarServidores',
    '🗑️ Excluir Servidor': 'excluirServidor',
    '📅 Alterar Data': 'alterarData',
    '🟢 Onlines': 'onlines',
    '⏳ Expirados': 'expirados',
    '📦 Backup': 'backup',
    '🔌 Alterar Limite': 'alterarLimite',
    '📤 Upload Backup': 'uploadBackup',
    '📥 Restaurar Backup': 'restaurarBackup'
  };

  const handlers = {};
  for (const [command, handlerName] of Object.entries(handlerMap)) {
    handlers[command] = loadHandler(handlerName);
  }

  try {
    const conexaoSSH = require('./utils/conexaoSSH');
    handlers['📃 Info. de Usuários'] = require('./handlers/informacoes')(conexaoSSH);
    console.log('✅ Handler de informações carregado');
  } catch (err) {
    console.error('❌ Erro no handler de informações:', err);
    handlers['📃 Info. de Usuários'] = (bot, msg) => {
      bot.sendMessage(msg.chat.id, '⚠️ Serviço indisponível', { parse_mode: 'Markdown' });
    };
  }

  return handlers;
};

const handlers = initHandlers();

// =============================================
// 6. MENU INLINE
// =============================================

const exibirMenuComBotoes = (chatId) => {
  const mensagemMenu = `
=*==*==*==*==*==*==*==*==*==*==*=*==*=*==*=*==*= 
  *BEM VINDO AO GERENCIADOR DO SERVIDOR VPN* 
=*==*==*==*==*==*==*==*==*==*==*=*==*=*==*=*==*= 

⚠️ *SELECIONE UMA OPÇÃO ABAIXO!*
`;

  const menu = {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🟢 Onlines', callback_data: '🟢 Onlines' }],
        [
          { text: '📊 Add Servidor', callback_data: '📊 Add Servidor' },
          { text: '📋 Listar Servidores', callback_data: '📋 Listar Servidores' }
        ],
        [
          { text: '🗑️ Excluir Servidor', callback_data: '🗑️ Excluir Servidor' },
          { text: '⏳ Expirados', callback_data: '⏳ Expirados' }
        ],
        [
          { text: '👤 Criar Usuário', callback_data: '👤 Criar Usuário' },
          { text: '📝 Criar Teste', callback_data: '📝 Criar Teste' }
        ],
        [
          { text: '🔑 Alterar Senha', callback_data: '🔑 Alterar Senha' },
          { text: '🔌 Alterar Limite', callback_data: '🔌 Alterar Limite' }
        ],
        [
          { text: '📅 Alterar Data', callback_data: '📅 Alterar Data' },
          { text: '📃 Info. de Usuários', callback_data: '📃 Info. de Usuários' }
        ],
        [
          { text: '❌ Remover', callback_data: '❌ Remover' },
          { text: '📦 Backup', callback_data: '📦 Backup' }
        ],
        [
          { text: '📤 Upload Backup', callback_data: '📤 Upload Backup' },
          { text: '📥 Restaurar Backup', callback_data: '📥 Restaurar Backup' }
        ]
      ]
    },
    parse_mode: 'Markdown'
  };

  bot.sendMessage(chatId, mensagemMenu, menu);
};

// =============================================
// 7. LÓGICA PRINCIPAL DO BOT
// =============================================

bot.onText(/\/start/, (msg) => {
  if (!isAdmin(msg)) {
    return bot.sendMessage(msg.chat.id, '🔒 Acesso restrito');
  }
  exibirMenuComBotoes(msg.chat.id);
});

bot.onText(/\/menu/, (msg) => {
  if (!isAdmin(msg)) {
    return bot.sendMessage(msg.chat.id, '🔒 Acesso restrito');
  }
  exibirMenuComBotoes(msg.chat.id);
});

bot.on('callback_query', async (callbackQuery) => {
  const action = callbackQuery.data;
  const msg = callbackQuery.message;

  if (!isAdmin(callbackQuery)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: '🔒 Acesso restrito!' });
  }

  const handler = handlers[action];
  if (handler) {
    try {
      await handler(bot, msg, {
        reply_markup: {
          inline_keyboard: [[{ text: '⬅️ Voltar ao menu', callback_data: '/menu' }]]
        }
      });
    } catch (err) {
      await bot.answerCallbackQuery(callbackQuery.id, { text: '❌ Função não implementada.' });
    }

    await bot.answerCallbackQuery(callbackQuery.id);
  }
});

// =============================================
// 8. ENCERRAMENTO SEGURO
// =============================================

const gracefulShutdown = async () => {
  console.log('\n🛑 Encerrando o bot...');
  try {
    if (bot && bot.stopPolling) await bot.stopPolling();
    if (fs.existsSync(LOCK_FILE)) fs.unlinkSync(LOCK_FILE);
    console.log('✅ Bot encerrado corretamente');
    process.exit(0);
  } catch (err) {
    console.error('❌ Erro no encerramento:', err);
    process.exit(1);
  }
};

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
process.on('uncaughtException', (err) => {
  console.error('💥 Erro não tratado:', err);
  gracefulShutdown();
});

console.log('✅ Bot iniciado com sucesso');
