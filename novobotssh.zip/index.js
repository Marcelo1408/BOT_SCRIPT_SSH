require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

console.log('🚀 Iniciando bot...');

// =============================================
// 1. CONFIGURAÇÃO INICIAL
// =============================================

const requiredEnvVars = ['BOT_TOKEN', 'ADM_ID', 'SERVER_HOST', 'SERVER_USER', 'SERVER_PASSWORD'];
const missingVars = requiredEnvVars.filter(v => !process.env[v]);

if (missingVars.length > 0) {
  console.error(`❌ Variáveis de ambiente ausentes: ${missingVars.join(', ')}`);
  process.exit(1);
}

console.log('✅ Variáveis de ambiente carregadas');

// Configuração de arquivos de dados
const ensureDataFiles = () => {
  const dataDir = path.join(__dirname, 'data');
  const usersFile = path.join(dataDir, 'usuarios.json');
  const backupsDir = path.join(__dirname, 'backups');

  try {
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');
    if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
    console.log('✅ Arquivos de dados verificados');
  } catch (err) {
    console.error('❌ Erro ao configurar arquivos de dados:', err);
    process.exit(1);
  }
};
ensureDataFiles();

// =============================================
// 2. INICIALIZAÇÃO DO BOT
// =============================================

const initBot = () => {
  try {
    console.log('🤖 Inicializando bot Telegram...');
    const bot = new TelegramBot(process.env.BOT_TOKEN, {
      polling: {
        interval: 5000, // Aumentado para 5 segundos
        params: {
          timeout: 60,
          allowed_updates: ['message', 'callback_query']
        }
      },
      request: { 
        timeout: 30000,
        proxy: null // Força não usar proxy
      }
    });

    bot.on('polling_error', (error) => {
      console.error('⚠️ Erro no polling:', error.message);
      // Não reinicia automaticamente em caso de erro
    });

    bot.setMyCommands([
      { command: 'start', description: 'Iniciar o bot' },
      { command: 'menu', description: 'Mostrar menu' }
    ]);

    console.log('✅ Bot Telegram inicializado');
    return bot;
  } catch (err) {
    console.error('❌ Falha ao criar instância do bot:', err);
    process.exit(1);
  }
};

const bot = initBot();

// =============================================
// 3. FUNÇÕES AUXILIARES
// =============================================

const carregarUsuarios = () => {
  try {
    const usuariosPath = path.join(__dirname, 'data', 'usuarios.json');
    return JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
  } catch (err) {
    console.error('Erro ao carregar usuários:', err);
    return [];
  }
};

const isAdmin = (msg) => {
  return msg.from?.id.toString() === process.env.ADM_ID;
};

// =============================================
// 4. HANDLERS SIMPLIFICADOS
// =============================================

const loadHandler = (handlerName) => {
  const handlerPath = path.join(__dirname, 'handlers', `${handlerName}.js`);
  try {
    if (!fs.existsSync(handlerPath)) {
      throw new Error('Arquivo não encontrado');
    }
    
    delete require.cache[require.resolve(handlerPath)];
    const handler = require(handlerPath);
    
    if (typeof handler !== 'function') {
      throw new Error('Exportação inválida');
    }
    
    console.log(`✅ Handler ${handlerName} carregado`);
    return handler;
  } catch (err) {
    console.error(`❌ Falha ao carregar ${handlerName}: ${err.message}`);
    return (bot, msg) => {
      bot.sendMessage(msg.chat.id, '⚠️ Comando temporariamente indisponível', {
        parse_mode: 'Markdown'
      });
    };
  }
};

const initHandlers = () => {
  console.log('🔄 Inicializando handlers...');
  
  // APENAS HANDLERS ESSENCIAIS - remova os problemáticos
  const handlerMap = {
    '👤 Criar Usuário': 'criarUsuario',
    '📝 Criar Teste': 'criarTeste',
    '❌ Remover': 'removerUsuario',
    '🔑 Alterar Senha': 'alterarSenha',
    '📊 Add Servidor': 'addServidor',
    '📋 Listar Servidores': 'listarServidores',
    '🗑️ Excluir Servidor': 'excluirServidor',
    '📅 Alterar Data': 'alterarData',
    '🟢 Onlines': 'onlines',
    '⏳ Expirados': 'expirados',
    '📦 Backup': 'backup',
    '🔌 Alterar Limite': 'alterarLimite',
    '📤 Upload Backup': 'uploadBackup', // REMOVIDO
    '📥 Restaurar Backup': 'restaurarBackup', // REMOVIDO
  };

  const handlers = {};
  for (const [command, handlerName] of Object.entries(handlerMap)) {
    handlers[command] = loadHandler(handlerName);
  }

  // Handler de informações com fallback
  handlers['📃 Info. de Usuários'] = (bot, msg) => {
    bot.sendMessage(msg.chat.id, 'ℹ️ Serviço de informações temporariamente offline', {
      parse_mode: 'Markdown'
    });
  };

  console.log('✅ Handlers essenciais carregados');
  return handlers;
};

const handlers = initHandlers();

// =============================================
// 5. MENUS SIMPLIFICADOS
// =============================================

const menuPrincipal = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '🟢 Onlines', callback_data: '🟢 Onlines' }],
      [{ text: '👤 Menu Usuários', callback_data: 'menu_usuarios' }],
      [{ text: '📦 Backup Local', callback_data: '📦 Backup' }],
      [{ text: '🔄 Recarregar', callback_data: '/menu' }]
    ]
  },
  parse_mode: 'Markdown'
};

const menuUsuarios = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '👤 Criar Usuário', callback_data: '👤 Criar Usuário' }],
      [{ text: '📝 Criar Teste', callback_data: '📝 Criar Teste' }],
      [{ text: '🔑 Alterar Senha', callback_data: '🔑 Alterar Senha' }],
      [{ text: '🔌 Alterar Limite', callback_data: '🔌 Alterar Limite' }],
      [{ text: '📅 Alterar Data', callback_data: '📅 Alterar Data' }],
      [{ text: '❌ Remover', callback_data: '❌ Remover' }],
      [{ text: '⬅️ Voltar', callback_data: 'voltar_menu_principal' }]
    ]
  },
  parse_mode: 'Markdown'
};

const exibirMenu = (chatId, messageId = null, menuType = 'principal') => {
  const mensagem = menuType === 'usuarios' 
    ? '👤 *MENU DE USUÁRIOS* 👤\n\nSelecione uma opção:' 
    : '🎮 *MENU PRINCIPAL* 🎮\n\nSelecione uma opção:';
  
  const menu = menuType === 'usuarios' ? menuUsuarios : menuPrincipal;

  if (messageId) {
    bot.editMessageText(mensagem, {
      chat_id: chatId,
      message_id: messageId,
      ...menu,
    }).catch(console.error);
  } else {
    bot.sendMessage(chatId, mensagem, menu);
  }
};

// =============================================
// 6. COMANDOS PRINCIPAIS
// =============================================

bot.onText(/\/start|\/menu/, (msg) => {
  if (!isAdmin(msg)) {
    return bot.sendMessage(msg.chat.id, '🔒 Acesso restrito');
  }
  exibirMenu(msg.chat.id);
});

bot.on('callback_query', async (callbackQuery) => {
  const action = callbackQuery.data;
  const msg = callbackQuery.message;
  const chatId = msg.chat.id;

  if (!isAdmin(callbackQuery)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: '🔒 Acesso restrito!' });
  }

  try {
    await bot.answerCallbackQuery(callbackQuery.id);

    if (action === 'menu_usuarios') {
      return exibirMenu(chatId, msg.message_id, 'usuarios');
    } else if (action === 'voltar_menu_principal') {
      return exibirMenu(chatId, msg.message_id, 'principal');
    } else {
      const handler = handlers[action];
      if (handler) {
        await handler(bot, msg);
      }
    }
  } catch (err) {
    console.error('❌ Erro no callback:', err);
    bot.sendMessage(chatId, '❌ Erro ao processar comando');
  }
});

// =============================================
// 7. TRATAMENTO DE ERROS GLOBAIS
// =============================================

process.on('uncaughtException', (error) => {
  console.error('💥 Erro não tratado:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('💥 Promise rejeitada:', reason);
});

console.log('✅ Bot iniciado com sucesso');
console.log('👮 ID do Admin:', process.env.ADM_ID);