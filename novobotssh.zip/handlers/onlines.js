const ConexaoSSH = require('../utils/conexaoSSH');

module.exports = async (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;

  // FunÃ§Ã£o para formatar o tempo de conexÃ£o (mesma que vocÃª jÃ¡ tinha)
  function formatTime(time) {
    if (!time) return 'ativo agora';

    if (time.match(/^\d+:\d+:\d+$/)) {
      return time.split(':').slice(0, 2).join(':') + 'h';
    }

    if (time.includes('-')) {
      const [days, hms] = time.split('-');
      const hours = hms.split(':')[0];
      return `${days}d ${hours}h`;
    }

    return time;
  }

  try {
    const sshCon = new ConexaoSSH();
    const ssh = await sshCon.conectar();

    const processingMsg = await bot.sendMessage(chatId, 'ðŸ”„ Verificando usuÃ¡rios online...');

    const cmd = `
      awk -F: '$3>=1000{print $1}' /etc/passwd | grep -v nobody | while read user; do
        sshd=$(ps -o etime= -u "$user" | grep -v '00:00' | wc -l);
        [ "$sshd" -gt 0 ] && {
          time=$(ps -o etime= -u "$user" | head -n1 | awk '{print $1}');
          echo "$user $time";
        };
      done
    `;

    const onlineResult = await ssh.execCommand(cmd);

    await sshCon.desconectar();

    const onlineUsers = onlineResult.stdout.split('\n')
      .filter(line => line.trim() !== '')
      .map(line => {
        const [username, time] = line.trim().split(/\s+/);
        return {
          username,
          time: formatTime(time)
        };
      });

    let message = 'ðŸ‘¤ *UsuÃ¡rios Online*:\n\n';
    
    if (onlineUsers.length === 0) {
      message += 'Nenhum usuÃ¡rio conectado no momento.\n';
    } else {
      onlineUsers.forEach(user => {
        message += `ðŸŸ¢ *${user.username}* (${user.time})\n\n`;
      });
      message += `ðŸ“Š Total: *${onlineUsers.length}* usuÃ¡rio(s) online`;
    }

    await bot.deleteMessage(chatId, processingMsg.message_id);
    await bot.sendMessage(chatId, message, {
      parse_mode: 'Markdown',
      reply_markup: menuPrincipal.reply_markup
    });

  } catch (error) {
    console.error('âŒ Erro ao verificar usuÃ¡rios online:', error);
    await bot.sendMessage(
      chatId,
      'âŒ Erro ao verificar usuÃ¡rios online. Verifique os logs do servidor.',
      { reply_markup: menuPrincipal.reply_markup }
    );
  }
};
