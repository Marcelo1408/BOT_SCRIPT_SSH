const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const backupDir = '/root';
const usuariosDir = '/root/bot-ssh/data';
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

// Garante que o diretório de usuários existe
if (!fs.existsSync(usuariosDir)) {
    fs.mkdirSync(usuariosDir, { recursive: true });
}

const estados = {};

async function criarUsuarioCompleto(conexaoSSH, usuario, chatId, bot) {
    try {
        // 1. Criar usuário no SSH
        await conexaoSSH.criarUsuario(
            usuario.username,
            usuario.senha,
            usuario.expira_em ? new Date(usuario.expira_em) : null,
            usuario.limite_conexoes || 1
        );

        // 2. Atualizar arquivo usuarios.json
        let usuariosAtuais = [];
        if (fs.existsSync(usuariosPath)) {
            usuariosAtuais = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        // Remove usuário existente (se houver)
        usuariosAtuais = usuariosAtuais.filter(u => u.username !== usuario.username);

        // Adiciona novo usuário
        const novoUsuario = {
            username: usuario.username,
            senha: usuario.senha,
            data_criacao: new Date().toISOString(),
            expira_em: usuario.expira_em || null,
            limite_conexoes: usuario.limite_conexoes || 1,
            ultima_atualizacao: new Date().toISOString()
        };

        usuariosAtuais.push(novoUsuario);
        fs.writeFileSync(usuariosPath, JSON.stringify(usuariosAtuais, null, 2));

        return {
            success: true,
            message: `✅ ${usuario.username} criado e registrado com sucesso!`
        };

    } catch (error) {
        return {
            success: false,
            message: `❌ Erro ao criar ${usuario.username}: ${error.message}`
        };
    }
}

module.exports = async (bot, msg, menuPrincipal) => {
    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Finalize a operação atual antes de iniciar outra.', menuPrincipal);
    }

    estados[chatId] = { bot, menuPrincipal };

    try {
        // Listar backups disponíveis
        const backups = fs.readdirSync(backupDir)
            .filter(file => file.endsWith('.json') && file.startsWith('backup_'))
            .sort((a, b) => fs.statSync(path.join(backupDir, b)).mtime.getTime() - fs.statSync(path.join(backupDir, a)).mtime.getTime());

        if (backups.length === 0) {
            throw new Error('Nenhum backup encontrado em /root (formato: backup_*.json)');
        }

        // Criar teclado com opções
        const teclado = backups.map((backup, index) => [{
            text: `${index + 1}. ${backup}`,
            callback_data: `restaurar_${index}`
        }]);

        teclado.push([{ text: '❌ Cancelar', callback_data: 'cancelar' }]);

        await bot.sendMessage(chatId, '📂 Selecione o backup para restaurar:', {
            reply_markup: { inline_keyboard: teclado }
        });

        // Configurar listener para seleção
        bot.once('callback_query', async callbackQuery => {
            const data = callbackQuery.data;

            if (data === 'cancelar') {
                delete estados[chatId];
                return bot.sendMessage(chatId, '❌ Operação cancelada.', menuPrincipal);
            }

            if (data.startsWith('restaurar_')) {
                const index = parseInt(data.split('_')[1]);
                const backupFile = backups[index];
                const backupPath = path.join(backupDir, backupFile);

                try {
                    const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
                    const usuarios = Array.isArray(backupData) ? backupData : backupData.usuarios || [];

                    if (usuarios.length === 0) {
                        throw new Error('O backup não contém usuários válidos');
                    }

                    await bot.sendMessage(chatId, `🔄 Iniciando restauração de ${usuarios.length} usuários...`);

                    const conexaoSSH = new ConexaoSSH();
                    await conexaoSSH.conectar();

                    // Processar cada usuário
                    for (const usuario of usuarios) {
                        const resultado = await criarUsuarioCompleto(conexaoSSH, usuario, chatId, bot);
                        await bot.sendMessage(chatId, resultado.message);
                        
                        // Pequena pausa entre usuários
                        await new Promise(resolve => setTimeout(resolve, 500));
                    }

                    await conexaoSSH.desconectar();

                    // Verificação final
                    const usuariosCriados = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
                    await bot.sendMessage(
                        chatId,
                        `🎉 Restauração concluída!\n` +
                        `📊 Total: ${usuarios.length} usuários processados\n` +
                        `📝 Registrados: ${usuariosCriados.length} usuários no sistema`,
                        menuPrincipal
                    );

                } catch (error) {
                    await bot.sendMessage(chatId, `❌ Erro crítico: ${error.message}`, menuPrincipal);
                } finally {
                    delete estados[chatId];
                }
            }
        });

    } catch (error) {
        await bot.sendMessage(chatId, `❌ Erro: ${error.message}`, menuPrincipal);
        delete estados[chatId];
    }
};