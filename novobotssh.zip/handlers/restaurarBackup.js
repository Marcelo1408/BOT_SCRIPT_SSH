const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const backupDir = '/root/backups';
const usuariosPath = '/root/bot-ssh/data/usuarios.json';

// Garante que o diretório de backups existe
if (!fs.existsSync(backupDir)) {
  fs.mkdirSync(backupDir, { recursive: true });
}

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já existe uma operação em andamento para este chat. Complete ou cancele antes de iniciar outra.', menuPrincipal);
    }

    estados[chatId] = {
        etapa: 'inicio',
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarProcessoRestauracao(bot, chatId, menuPrincipal);
};

async function iniciarProcessoRestauracao(bot, chatId, menuPrincipal) {
    try {
        // Listar arquivos de backup disponíveis
        const backups = fs.readdirSync(backupDir)
            .filter(file => file.endsWith('.json'))
            .sort((a, b) => {
                return fs.statSync(path.join(backupDir, b)).mtime.getTime() - 
                       fs.statSync(path.join(backupDir, a)).mtime.getTime();
            });

        if (backups.length === 0) {
            await bot.sendMessage(chatId, '❌ Nenhum arquivo de backup encontrado no diretório.', menuPrincipal);
            return limparEstado(chatId);
        }

        // Criar teclado com opções de backup
        const teclado = backups.map((backup, index) => {
            const stats = fs.statSync(path.join(backupDir, backup));
            const dataModificacao = stats.mtime.toLocaleString('pt-BR');
            return [{ 
                text: `${index + 1}. ${backup} (${dataModificacao})`,
                callback_data: `backup_${index}`
            }];
        });

        // Adicionar opção de cancelamento
        teclado.push([{ text: '❌ Cancelar', callback_data: 'cancelar' }]);

        estados[chatId].backups = backups;

        await bot.sendMessage(chatId, '📂 Selecione o arquivo de backup para restaurar:', {
            reply_markup: { inline_keyboard: teclado }
        });

    } catch (error) {
        console.error('Erro ao listar backups:', error);
        await bot.sendMessage(chatId, '❌ Ocorreu um erro ao acessar os backups.', menuPrincipal);
        limparEstado(chatId);
    }
}

// Configurar listeners para interações
module.exports.setupListeners = (bot) => {
    bot.on('callback_query', async (callbackQuery) => {
        const chatId = callbackQuery.message.chat.id;
        const data = callbackQuery.data;

        if (!estados[chatId]) return;

        try {
            if (data === 'cancelar') {
                await bot.sendMessage(chatId, '❌ Operação cancelada.', estados[chatId].menuPrincipal);
                return limparEstado(chatId);
            }

            if (data.startsWith('backup_')) {
                const index = parseInt(data.split('_')[1]);
                const backupSelecionado = estados[chatId].backups[index];

                if (!backupSelecionado) {
                    throw new Error('Backup selecionado inválido');
                }

                estados[chatId].backupSelecionado = backupSelecionado;
                await solicitarConfirmacao(bot, chatId, backupSelecionado);
            }

            if (data === 'confirmar_restauracao') {
                await executarRestauracao(bot, chatId);
            }

            if (data === 'cancelar_restauracao') {
                await bot.sendMessage(chatId, '❌ Restauração cancelada.', estados[chatId].menuPrincipal);
                return limparEstado(chatId);
            }

        } catch (error) {
            console.error('Erro no callback:', error);
            await bot.sendMessage(chatId, `❌ Erro: ${error.message}`, estados[chatId].menuPrincipal);
            limparEstado(chatId);
        }
    });
};

async function solicitarConfirmacao(bot, chatId, backupSelecionado) {
    const backupPath = path.join(backupDir, backupSelecionado);
    const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
    const usuarios = Array.isArray(backupData) ? backupData : backupData.usuarios || [];

    if (usuarios.length === 0) {
        throw new Error('O backup selecionado não contém usuários válidos');
    }

    const teclado = [
        [{ text: '✅ Confirmar Restauração', callback_data: 'confirmar_restauracao' }],
        [{ text: '❌ Cancelar', callback_data: 'cancelar_restauracao' }]
    ];

    await bot.sendMessage(
        chatId,
        `⚠️ *CONFIRMAÇÃO DE RESTAURAÇÃO*\n\n` +
        `📂 Arquivo: ${backupSelecionado}\n` +
        `👤 Total de usuários: ${usuarios.length}\n` +
        `\nEsta ação irá:\n` +
        `1. Criar todos os usuários no servidor SSH\n` +
        `2. Substituir o arquivo atual de usuários\n\n` +
        `Deseja continuar?`,
        { 
            parse_mode: 'Markdown',
            reply_markup: { inline_keyboard: teclado } 
        }
    );
}

async function executarRestauracao(bot, chatId) {
    const { backupSelecionado, menuPrincipal, from_username } = estados[chatId];
    const backupPath = path.join(backupDir, backupSelecionado);

    try {
        const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
        const usuarios = Array.isArray(backupData) ? backupData : backupData.usuarios || [];

        if (usuarios.length === 0) {
            throw new Error('Nenhum usuário válido encontrado no backup');
        }

        await bot.sendMessage(chatId, `🔄 Iniciando restauração de ${usuarios.length} usuários...`);

        const conexaoSSH = new ConexaoSSH();
        await conexaoSSH.conectar();

        let sucessos = 0;
        let erros = 0;
        const detalhesErros = [];

        // Processar cada usuário individualmente
        for (const usuario of usuarios) {
            try {
                // Verificar se o usuário tem todos os campos necessários
                if (!usuario.username || !usuario.senha) {
                    throw new Error('Dados do usuário incompletos');
                }

                // Calcular dias restantes (para compatibilidade)
                const expiracao = usuario.expira_em ? new Date(usuario.expira_em) : null;
                const dias = expiracao ? Math.ceil((expiracao - new Date()) / (1000 * 60 * 60 * 24)) : 365;

                // Criar usuário no SSH
                await conexaoSSH.criarUsuario(
                    usuario.username,
                    usuario.senha,
                    expiracao,
                    usuario.limite_conexoes || 1
                );

                sucessos++;

                // Atualizar progresso a cada 5 usuários
                if (sucessos % 5 === 0) {
                    await bot.sendMessage(chatId, `✅ ${sucessos} usuários restaurados...`);
                }

            } catch (error) {
                console.error(`Erro ao restaurar usuário ${usuario.username || 'desconhecido'}:`, error);
                erros++;
                detalhesErros.push(`- ${usuario.username || 'Sem nome'}: ${error.message}`);
            }
        }

        await conexaoSSH.desconectar();

        // Atualizar arquivo de usuários
        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        // Enviar relatório final
        let mensagem = `✅ *RESTAURAÇÃO CONCLUÍDA!*\n\n` +
            `📂 Backup: ${backupSelecionado}\n` +
            `👤 Usuários restaurados: ${sucessos}\n` +
            `❌ Erros: ${erros}\n`;

        if (erros > 0) {
            mensagem += `\n📝 Detalhes dos erros:\n${detalhesErros.slice(0, 5).join('\n')}`;
            if (detalhesErros.length > 5) {
                mensagem += `\n... e mais ${detalhesErros.length - 5} erros`;
            }
        }

        await bot.sendMessage(chatId, mensagem, { parse_mode: 'Markdown', ...menuPrincipal });

        // Notificar administrador
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `🔙 *Backup Restaurado*\n\n` +
                `📂 Arquivo: ${backupSelecionado}\n` +
                `👤 Usuários: ${sucessos} restaurados | ${erros} erros\n` +
                `🔄 Por: @${from_username || 'desconhecido'}`,
                { parse_mode: 'Markdown' }
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro durante a restauração:', error);
        await bot.sendMessage(
            chatId,
            `❌ *Falha na restauração!*\n\n` +
            `Motivo: ${error.message}\n\n` +
            `Por favor, tente novamente.`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        delete estados[chatId];
    }
}