const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

module.exports = function (bot, msg, menuPrincipal) {
  const chatId = msg.chat.id;
  const backupDir = '/root';
  const usuariosPath = '/root/bot-ssh/data/usuarios.json';

  try {
    if (!fs.existsSync(backupDir)) {
      return bot.sendMessage(chatId, '❌ Nenhum backup disponível para restauração em /root.', menuPrincipal);
    }

    const backups = fs.readdirSync(backupDir)
      .filter(file => file.endsWith('.json') && file.startsWith('backup_'))
      .map((file, index) => `${index + 1}. ${file}`);

    if (backups.length === 0) {
      return bot.sendMessage(chatId, '❌ Nenhum backup disponível para restauração em /root.', menuPrincipal);
    }

    const keyboard = backups.map((backup, index) => [
      { text: `${index + 1}`, callback_data: `restore_${index}` }
    ]);

    bot.sendMessage(chatId, '📥 Selecione o backup que deseja restaurar:', {
      reply_markup: {
        inline_keyboard: keyboard
      }
    });

    bot.once('callback_query', async (callbackQuery) => {
      const data = callbackQuery.data;
      if (!data.startsWith('restore_')) return;

      const index = parseInt(data.split('_')[1]);
      const backupFiles = fs.readdirSync(backupDir)
        .filter(file => file.endsWith('.json') && file.startsWith('backup_'));
      const selectedBackup = backupFiles[index];

      if (!selectedBackup) {
        return bot.sendMessage(chatId, '❌ Backup selecionado inválido.', menuPrincipal);
      }

      try {
        const backupPath = path.join(backupDir, selectedBackup);
        const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
        const usuarios = Array.isArray(backupData) ? backupData : backupData.usuarios || [];

        let successCount = 0;
        let errorCount = 0;
        let errorDetails = [];

        const conexaoSSH = new ConexaoSSH();
        await bot.sendMessage(chatId, `🔄 Iniciando restauração do backup: ${selectedBackup}...`);

        for (const usuario of usuarios) {
          try {
            await conexaoSSH.criarUsuario(
              usuario.username,
              usuario.senha,
              usuario.expira_em,
              usuario.limite_conexoes
            );
            successCount++;
          } catch (err) {
            console.error(`Erro ao criar usuário ${usuario.username}:`, err);
            errorCount++;
            errorDetails.push(`- ${usuario.username}: ${err.message}`);
          }
        }

        await conexaoSSH.desconectar();

        if (errorCount === 0) {
          const dir = path.dirname(usuariosPath);
          if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
          }
          fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2), 'utf8');

          // Mensagem de sucesso SEM formatação Markdown
          const resposta = `
✅ BACKUP RESTAURADO COM SUCESSO!

📂 Arquivo restaurado: ${selectedBackup}
👥 Total de usuários: ${successCount}
🕒 Data/hora: ${new Date().toLocaleString()}

Todos os usuários foram criados com sucesso no servidor SSH e o arquivo de usuários foi atualizado.
          `;

          await bot.sendMessage(chatId, resposta, menuPrincipal);
          await bot.sendMessage(chatId, '🟢 A restauração foi concluída com êxito! Você pode verificar os usuários criados.', menuPrincipal);
        } else {
          // Mensagem de erro parcial SEM formatação Markdown
          const resposta = `
⚠️ RESTAURAÇÃO PARCIALMENTE CONCLUÍDA

📂 Arquivo: ${selectedBackup}
✅ Sucessos: ${successCount}
❌ Erros: ${errorCount}

Detalhes dos erros:
${errorDetails.join('\n')}

Os usuários com erro não foram adicionados ao arquivo.
          `;

          await bot.sendMessage(chatId, resposta, menuPrincipal);
          await bot.sendMessage(chatId, '🟡 A restauração foi concluída com alguns erros. Verifique os detalhes acima.', menuPrincipal);
        }

      } catch (error) {
        console.error('Erro na restauração:', error);
        // Mensagem de erro SEM formatação Markdown
        await bot.sendMessage(chatId, `❌ OCORREU UM ERRO DURANTE A RESTAURAÇÃO:\n${error.message}`, menuPrincipal);
      }
    });

  } catch (error) {
    console.error('Erro ao listar backups:', error);
    bot.sendMessage(chatId, '❌ Ocorreu um erro ao acessar os backups.', menuPrincipal);
  }
};