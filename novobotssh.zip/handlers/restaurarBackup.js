const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

module.exports = function(bot, msg, menuPrincipal) {
  const chatId = msg.chat.id;
  const backupDir = '/root'; // Agora busca na raiz
  const usuariosPath = path.join(__dirname, '..', 'data', 'usuarios.json');

  try {
    if (!fs.existsSync(backupDir)) {
      return bot.sendMessage(chatId, '❌ Nenhum backup disponível para restauração em /root.', menuPrincipal);
    }

    const backups = fs.readdirSync(backupDir)
      .filter(file => file.endsWith('.json') && file.startsWith('backup_'))
      .map((file, index) => `${index + 1}. ${file}`);

    if (backups.length === 0) {
      return bot.sendMessage(chatId, '❌ Nenhum backup disponível para restauração em /root.', menuPrincipal);
    }

    const keyboard = backups.map((backup, index) => [
      { text: `${index + 1}`, callback_data: `restore_${index}` }
    ]);

    bot.sendMessage(chatId, '📥 Selecione o backup que deseja restaurar:', {
      reply_markup: {
        inline_keyboard: keyboard
      }
    });

    bot.once('callback_query', async (callbackQuery) => {
      const data = callbackQuery.data;
      if (!data.startsWith('restore_')) return;

      const index = parseInt(data.split('_')[1]);
      const backupFiles = fs.readdirSync(backupDir)
        .filter(file => file.endsWith('.json') && file.startsWith('backup_'));
      const selectedBackup = backupFiles[index];

      if (!selectedBackup) {
        return bot.sendMessage(chatId, '❌ Backup selecionado inválido.', menuPrincipal);
      }

      try {
        const backupPath = path.join(backupDir, selectedBackup);
        const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
        const usuarios = Array.isArray(backupData) ? backupData : backupData.usuarios || [];

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        let successCount = 0;
        let errorCount = 0;

        for (const usuario of usuarios) {
          try {
            await conexaoSSH.criarUsuario(
              usuario.username,
              usuario.password,
              usuario.expiryDate,
              usuario.limit
            );
            successCount++;
          } catch (err) {
            console.error(`Erro ao criar usuário ${usuario.username}:`, err);
            errorCount++;
          }
        }

        const resposta = `
✅ *Backup restaurado com sucesso!*

📊 *Resultado:*
   - Usuários restaurados: ${successCount}
   - Erros: ${errorCount}
   - Arquivo: ${selectedBackup}
        `;

        bot.sendMessage(chatId, resposta, { parse_mode: 'Markdown', ...menuPrincipal });
        // Mensagem de confirmação extra
        bot.sendMessage(chatId, '✅ Restauração de usuários concluída com sucesso!');

        // Restaurar em múltiplos locais
        const caminhos = [
          'root/bot-ssh/data/usuarios.json',
          '/root/usuarios.json',
          '/root/usuarios.db',
          '/opt/zshmanager/limites'

        ];

        caminhos.forEach((caminho) => {
          try {
            fs.writeFileSync(caminho, JSON.stringify(usuarios, null, 2), 'utf8');
            console.log(`Backup restaurado em: ${caminho}`);
          } catch (err) {
            console.error(`Erro ao restaurar em ${caminho}:`, err.message);
          }
        });

      } catch (error) {
        console.error('Erro na restauração:', error);
        bot.sendMessage(chatId, '❌ Ocorreu um erro ao restaurar o backup.', menuPrincipal);
      }
    });

  } catch (error) {
    console.error('Erro ao listar backups:', error);
    bot.sendMessage(chatId, '❌ Ocorreu um erro ao acessar os backups.', menuPrincipal);
  }
};