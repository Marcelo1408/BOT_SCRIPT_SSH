const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

module.exports = async function (bot, msg, menuPrincipal) {
  const chatId = msg.chat.id;
  const diretorioBackup = '/root';
  const caminhoUsuarios = '/root/bot-ssh/data/usuarios.json';

  try {
    // Verifica se existem backups disponíveis
    if (!fs.existsSync(diretorioBackup)) {
      return bot.sendMessage(chatId, '❌ Nenhum backup disponível para restauração em /root.', menuPrincipal);
    }

    // Lista todos os arquivos de backup
    const backups = fs.readdirSync(diretorioBackup)
      .filter(arquivo => arquivo.endsWith('.json') && arquivo.startsWith('backup_'))
      .map((arquivo, indice) => `${indice + 1}. ${arquivo}`);

    if (backups.length === 0) {
      return bot.sendMessage(chatId, '❌ Nenhum backup disponível para restauração em /root.', menuPrincipal);
    }

    // Cria o teclado de seleção de backup
    const teclado = backups.map((backup, indice) => [
      { text: `${indice + 1}`, callback_data: `restaurar_${indice}` }
    ]);

    bot.sendMessage(chatId, '📥 Selecione o backup que deseja restaurar:', {
      reply_markup: { inline_keyboard: teclado }
    });

    bot.once('callback_query', async (callbackQuery) => {
      const dados = callbackQuery.data;
      if (!dados.startsWith('restaurar_')) return;

      const indice = parseInt(dados.split('_')[1]);
      const arquivosBackup = fs.readdirSync(diretorioBackup)
        .filter(arquivo => arquivo.endsWith('.json') && arquivo.startsWith('backup_'));

      const backupSelecionado = arquivosBackup[indice];
      if (!backupSelecionado) {
        return bot.sendMessage(chatId, '❌ Backup selecionado inválido.', menuPrincipal);
      }

      try {
        const caminhoBackup = path.join(diretorioBackup, backupSelecionado);
        const dadosBackup = JSON.parse(fs.readFileSync(caminhoBackup, 'utf8'));
        const usuarios = Array.isArray(dadosBackup) ? dadosBackup : dadosBackup.usuarios || [];

        // Lê os usuários existentes
        let usuariosExistentes = [];
        if (fs.existsSync(caminhoUsuarios)) {
          usuariosExistentes = JSON.parse(fs.readFileSync(caminhoUsuarios, 'utf8'));
        }

        let sucessos = 0;
        let erros = 0;
        const detalhesErros = [];

        const conexaoSSH = new ConexaoSSH();
        await bot.sendMessage(chatId, `🔄 Iniciando restauração do backup: ${backupSelecionado}...`);

        // Processa cada usuário individualmente
        for (const usuario of usuarios) {
          try {
            // Cria o usuário no servidor SSH
            await conexaoSSH.criarUsuario(
              usuario.username,
              usuario.senha,
              usuario.expira_em,
              usuario.limite_conexoes
            );

            // Remove duplicatas
            usuariosExistentes = usuariosExistentes.filter(u => u.username !== usuario.username);

            // Adiciona o usuário restaurado
            usuariosExistentes.push({
              username: usuario.username,
              senha: usuario.senha,
              expira_em: usuario.expira_em || null,
              limite_conexoes: usuario.limite_conexoes || 1,
              data_criacao: new Date().toISOString(),
              ultima_atualizacao: new Date().toISOString()
            });

            sucessos++;
            
            // Envia atualização a cada 10 usuários criados
            if (sucessos % 10 === 0) {
              await bot.sendMessage(chatId, `✅ ${sucessos} usuários criados até agora...`);
            }
          } catch (erro) {
            console.error(`Erro ao criar usuário ${usuario.username}:`, erro);
            erros++;
            detalhesErros.push(`- ${usuario.username}: ${erro.message}`);
          }
        }

        await conexaoSSH.desconectar();

        // Atualiza o arquivo de usuários
        const diretorio = path.dirname(caminhoUsuarios);
        if (!fs.existsSync(diretorio)) fs.mkdirSync(diretorio, { recursive: true });
        fs.writeFileSync(caminhoUsuarios, JSON.stringify(usuariosExistentes, null, 2), 'utf8');

        // Mensagem de resultado
        if (erros === 0) {
          const mensagem = 
`✅ BACKUP RESTAURADO COM SUCESSO!

📂 Arquivo restaurado: ${backupSelecionado}
👥 Total de usuários: ${sucessos}
🕒 Data/hora: ${new Date().toLocaleString()}`;
          await bot.sendMessage(chatId, mensagem, menuPrincipal);
        } else {
          const mensagem = 
`⚠️ RESTAURAÇÃO PARCIALMENTE CONCLUÍDA

📂 Arquivo: ${backupSelecionado}
✅ Sucessos: ${sucessos}
❌ Erros: ${erros}

Detalhes dos erros:
${detalhesErros.join('\n')}`;
          await bot.sendMessage(chatId, mensagem, menuPrincipal);
        }

      } catch (erro) {
        console.error('Erro na restauração:', erro);
        await bot.sendMessage(chatId, `❌ OCORREU UM ERRO DURANTE A RESTAURAÇÃO:\n${erro.message}`, menuPrincipal);
      }
    });

  } catch (erro) {
    console.error('Erro ao listar backups:', erro);
    bot.sendMessage(chatId, '❌ Ocorreu um erro ao acessar os backups.', menuPrincipal);
  }
};