module.exports = (conectarSSH) => {
    const getVpsInfo = async () => {
        const ssh = await conectarSSH();
        const execCommand = (cmd) =>
            new Promise((resolve, reject) => {
                ssh.exec(cmd, (err, stream) => {
                    if (err) reject(err);
                    let result = '';
                    stream
                        .on('close', () => resolve(result.trim()))
                        .on('data', (data) => (result += data))
                        .stderr.on('data', (data) => console.error(data));
                });
            });

        const commands = {
            uptime: 'uptime -p',
            osInfo: 'cat /etc/os-release',
            memory: 'free -m',
            disk: 'df -h /',
            cpu: "top -bn1 | grep 'Cpu(s)' | awk '{print $2 + $4}'",
            processes: 'ps aux | wc -l',
            network: "ip addr | grep 'state UP' | wc -l",
            lastLogin: 'last -a | head -n 1',
            sshUsers: "who | awk '{print $1}' | sort | uniq | wc -l",
            ipAddress: "hostname -I | awk '{print $1}'",
            dnsInfo: 'cat /etc/resolv.conf',
            kernelVersion: 'uname -r',
            openPorts: "ss -tuln | grep -E 'LISTEN' | wc -l"
        };

        const results = {};
        for (const key in commands) {
            try {
                results[key] = await execCommand(commands[key]);
            } catch (error) {
                results[key] = `Erro ao obter ${key}`;
            }
        }

        ssh.end();
        return results;
    };

    const formatVpsMessage = (info) => {
        return (
            `🖥️ *Informações da VPS:*\n\n` +
            `*⏳ Uptime:* ${info.uptime}\n` +
            `*🖥️ OS:* ${info.osInfo.split('\n')[0].replace('PRETTY_NAME="', '').replace('"', '')}\n` +
            `*🧠 Memória (MB):*\n${info.memory}\n` +
            `*💾 Disco:* ${info.disk}\n` +
            `*⚙️ Uso de CPU:* ${info.cpu}%\n` +
            `*📊 Processos:* ${info.processes}\n` +
            `*🌐 Interfaces de Rede Ativas:* ${info.network}\n` +
            `*🔐 Usuários SSH conectados:* ${info.sshUsers}\n` +
            `*📡 IP:* ${info.ipAddress}\n` +
            `*📝 Último login:* ${info.lastLogin}\n` +
            `*🔍 DNS:* \n${info.dnsInfo}\n` +
            `*🖥️ Kernel:* ${info.kernelVersion}\n` +
            `*🛡️ Portas Abertas:* ${info.openPorts}`
        );
    };

    const handler = async (bot, msg, menuPrincipal) => {
        const chatId = msg.chat.id;

        try {
            await bot.sendChatAction(chatId, 'typing');

            const loadingMsg = await bot.sendMessage(
                chatId,
                '🔍 Verificando status completo da VPS...',
                { reply_markup: { remove_keyboard: true } }
            );

            const vpsInfo = await getVpsInfo();

            const message = formatVpsMessage(vpsInfo);

            await bot.editMessageText(message, {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'Markdown',
                reply_markup: menuPrincipal.reply_markup
            });

        } catch (error) {
            console.error('Erro no handler:', error);
            bot.sendMessage(
                chatId,
                '❌ Falha ao verificar a VPS. Verifique:\n' +
                '1. Conexão com o servidor\n' +
                '2. Permissões SSH\n' +
                '3. Logs do sistema',
                { reply_markup: menuPrincipal.reply_markup }
            );
        }
    };

    return { getVpsInfo, handler };
};
