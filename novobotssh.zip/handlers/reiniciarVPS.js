require('dotenv').config();
const conexaoSSH = require('../utils/conexaoSSH');

module.exports = async (bot, msg) => {
  const chatId = msg.chat.id;

  // Verificação PROFISSIONAL das variáveis
  const validarPorta = (port) => {
    const porta = parseInt(port || '22');
    return !isNaN(porta) && porta > 0 && porta <= 65535;
  };

  if (!validarPorta(process.env.SERVER_PORT)) {
    return bot.sendMessage(chatId, 
      "❌ Porta SSH inválida no arquivo .env!\n" +
      `Porta atual: ${process.env.SERVER_PORT}\n` +
      "Use um valor entre 1 e 65535 (ex.: 22)."
    );
  }

  try {
    // Confirmação EXTRA segura
    await bot.sendMessage(
      chatId,
      `⚠️ **Você está prestes a reiniciar:**\n` +
      `🔗 Servidor: ${process.env.SERVER_HOST}\n` +
      `👤 Usuário: ${process.env.SERVER_USER}\n` +
      `🚪 Porta: ${process.env.SERVER_PORT}\n\n` +
      `Digite **CONFIRMAR REBOOT** para prosseguir.`
    );

    bot.once('message', async (resposta) => {
      if (resposta.text === 'CONFIRMAR REBOOT' && resposta.chat.id === chatId) {
        await bot.sendMessage(chatId, "🔄 Executando reinício seguro...");

        // Script de reinício OTIMIZADO
        const comandoReinicio = `
          sudo pkill -9 -f 'sshd:.*' &&       # Encerra conexões
          sudo pm2 save &&                    # Salva estado do PM2
          sudo nohup reboot &                 # Reinicia em background
          exit 0                              # Encerra a sessão SSH
        `;

        // Execução DIRETA via SSH (sem arquivos temporários)
        await conexaoSSH.executarComando(comandoReinicio);
        
        await bot.sendMessage(
          chatId,
          "✅ Comando de reinício aceito!\n\n" +
          "A VPS está reiniciando agora...\n" +
          "O bot voltará em 1-2 minutos via PM2."
        );

      } else {
        await bot.sendMessage(chatId, "❌ Reinício cancelado pelo usuário.");
      }
    });

  } catch (error) {
    await bot.sendMessage(
      chatId,
      `❌ Falha crítica:\n${error.message}\n\n` +
      "Verifique:\n" +
      "1. Credenciais SSH no arquivo .env\n" +
      "2. Permissões sudo para o usuário\n" +
      "3. Porta SSH aberta no firewall"
    );
  }
};