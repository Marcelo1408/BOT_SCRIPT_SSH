const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

module.exports = async (bot) => {
  const usuariosPath = path.join(__dirname, '..', 'data', 'usuarios.json');

  if (!fs.existsSync(usuariosPath)) {
    console.log('Nenhum arquivo de usuários encontrado para varrer.');
    return;
  }

  let usuarios;
  try {
    usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
  } catch (err) {
    console.error('Erro ao ler arquivo de usuários:', err.message);
    return;
  }

  const agora = new Date();
  const expirados = [];

  for (const usuario of usuarios) {
    if (usuario.expiracao) {
      const expiraEm = new Date(usuario.expiracao);
      if (expiraEm < agora && usuario.status !== 'expirado') {
        // Bloqueia o usuário no servidor via SSH
        try {
          const comando = `usermod -L ${usuario.nome}`;
          await conexaoSSH.execCommand(comando);
          console.log(`Usuário ${usuario.nome} bloqueado no servidor.`);
        } catch (err) {
          console.error(`Erro ao bloquear usuário ${usuario.nome}:`, err.message);
        }

        // Atualiza status no arquivo JSON
        usuario.status = 'expirado';
        expirados.push(usuario);
      }
    }
  }

  if (expirados.length > 0) {
    fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2), 'utf8');

    const mensagem = `⏳ *${expirados.length} usuário(s)/teste(s) expirado(s)* bloqueado(s) automaticamente no servidor.`;

    bot.sendMessage(process.env.ADM_ID, mensagem, { parse_mode: 'Markdown' });

    console.log(`${expirados.length} usuário(s)/teste(s) expirado(s) bloqueado(s) e atualizados.`);
  } else {
    console.log('Nenhum usuário expirado encontrado nesta varredura.');
  }
};

