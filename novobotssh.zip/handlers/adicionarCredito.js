const fs = require('fs');
const path = require('path');

module.exports = function(bot, msg, menuPrincipal) {
  const chatId = msg.chat.id;
  const revendasPath = path.join(__dirname, '..', 'data', 'revendas.json');
  
  // Verifica se é admin
  if (msg.from.id.toString() !== process.env.ADM_ID) {
    return bot.sendMessage(chatId, '❌ Apenas o administrador pode adicionar crédito.', menuPrincipal);
  }

  const estados = {};
  estados[chatId] = { etapa: 'idTelegram' };

  // Carrega revendas existentes
  const revendas = JSON.parse(fs.readFileSync(revendasPath, 'utf8'));
  
  if (revendas.length === 0) {
    return bot.sendMessage(chatId, '❌ Nenhuma revenda cadastrada.', menuPrincipal);
  }

  // Lista revendas para seleção
  const listaRevendas = revendas.map(r => `- ${r.nome} (ID: ${r.idTelegram}) - Crédito: ${r.credito}`).join('\n');
  
  bot.sendMessage(chatId, `Revendas disponíveis:\n\n${listaRevendas}\n\nDigite o ID do Telegram da revenda que deseja adicionar crédito:`);
  
  bot.once('message', (msg) => {
    if (msg.chat.id !== chatId) return;
    
    const idTelegram = msg.text;
    const revenda = revendas.find(r => r.idTelegram === idTelegram);
    
    if (!revenda) {
      return bot.sendMessage(chatId, '❌ Revenda não encontrada.', menuPrincipal);
    }
    
    estados[chatId].revenda = revenda;
    estados[chatId].etapa = 'credito';
    bot.sendMessage(chatId, `Revenda selecionada: ${revenda.nome}\nCrédito atual: ${revenda.credito}\n\nDigite a quantidade de crédito a adicionar:`);
    
    bot.once('message', (msg) => {
      if (msg.chat.id !== chatId) return;
      
      const creditoAdicional = parseInt(msg.text);
      if (isNaN(creditoAdicional)) {
        return bot.sendMessage(chatId, '❌ Valor inválido. Digite um número.', menuPrincipal);
      }
      
      // Atualiza o crédito
      revenda.credito += creditoAdicional;
      
      // Salva no arquivo
      fs.writeFileSync(revendasPath, JSON.stringify(revendas, null, 2));
      
      bot.sendMessage(chatId, `✅ Crédito adicionado com sucesso!\n\nRevenda: ${revenda.nome}\nNovo crédito: ${revenda.credito}`, menuPrincipal);
      delete estados[chatId];
    });
  });
};