const fs = require('fs');
const path = require('path');

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  const fileUsuarios = path.join(__dirname, '../data/usuarios.json');
  const backupPath = path.join('/root', `backup-${new Date().toISOString().slice(0, 10)}.json`); // Alterado para salvar em /root

  if (!fs.existsSync(fileUsuarios)) {
    return bot.sendMessage(chatId, '❌ Arquivo de usuários não encontrado para backup.', menuPrincipal);
  }

  try {
    const data = fs.readFileSync(fileUsuarios, 'utf8');
    
    // Verifica se o conteúdo é um JSON válido
    JSON.parse(data); // Isso vai lançar um erro se não for válido
    
    fs.writeFileSync(backupPath, data, 'utf8');

    bot.sendDocument(chatId, backupPath, {
      caption: '📦 Backup dos usuários', // Removido .json da legenda
      ...menuPrincipal.reply_markup ? {reply_markup: menuPrincipal.reply_markup} : {}
    });

  } catch (err) {
    console.error('Erro ao criar/enviar backup:', err);
    bot.sendMessage(
      chatId, 
      `❌ Falha ao criar o backup: ${err.message}`,
      menuPrincipal
    );
  }
};
