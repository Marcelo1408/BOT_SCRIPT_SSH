const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosPath = path.join('/root/bot-ssh/data/usuarios.json');
const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    const chatId = msg.chat.id;
    if (!chatId) return;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Finalize ou cancele a anterior.', menuPrincipal);
    }

    estados[chatId] = {
        etapa: 'usuario',
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    solicitarUsuario(bot, chatId);
};

function solicitarUsuario(bot, chatId) {
    bot.sendMessage(chatId, '👤 Digite o nome do usuário que deseja alterar a validade:')
        .then(() => {
            const listener = async (res) => {
                if (res.chat.id !== chatId) return;

                const username = res.text.trim().toLowerCase();

                if (!/^[a-z_][a-z0-9_-]{0,31}$/i.test(username)) {
                    await bot.sendMessage(chatId, '❌ Nome inválido! Deve ter entre 1 e 32 caracteres (letras, números, _ ou -)', estados[chatId].menuPrincipal);
                    return limparEstado(chatId);
                }

                estados[chatId].username = username;

                try {
                    const ssh = await new ConexaoSSH().conectar();
                    const { stdout } = await ssh.execCommand(`id ${username} >/dev/null 2>&1 && echo "EXISTS" || echo "NOT_FOUND"`);
                    ssh.dispose();

                    if (stdout.includes('NOT_FOUND')) throw new Error('Usuário não encontrado no servidor');

                    // Verifica no arquivo local
                    let usuarios = fs.existsSync(usuariosPath) ? JSON.parse(fs.readFileSync(usuariosPath, 'utf8')) : [];
                    const usuario = usuarios.find(u => u.username === username);
                    estados[chatId].dataAtual = usuario?.expira_em || null;

                    solicitarDias(bot, chatId);
                } catch (err) {
                    await bot.sendMessage(chatId, `❌ ${err.message}`, estados[chatId].menuPrincipal);
                    limparEstado(chatId);
                }
            };

            estados[chatId].messageListener = listener;
            bot.once('message', listener);
        });
}

function solicitarDias(bot, chatId) {
    const { username, dataAtual } = estados[chatId];
    const formatar = (d) => d ? new Date(d).toLocaleDateString('pt-BR') : 'Sem expiração';

    bot.sendMessage(chatId, `📅 *Usuário:* \`${username}\`\n📆 *Data atual:* ${formatar(dataAtual)}\n\nDigite o número de dias a adicionar (0 para remover a expiração):`, { parse_mode: 'Markdown' })
        .then(() => {
            const listener = async (res) => {
                if (res.chat.id !== chatId) return;

                const dias = parseInt(res.text.trim(), 10);
                if (isNaN(dias) || dias < 0) {
                    await bot.sendMessage(chatId, '❌ Número inválido!', estados[chatId].menuPrincipal);
                    return limparEstado(chatId);
                }

                estados[chatId].dias = dias;
                await alterarValidade(bot, chatId);
            };

            estados[chatId].messageListener = listener;
            bot.once('message', listener);
        });
}

async function alterarValidade(bot, chatId) {
    const { username, dias, from_username } = estados[chatId];

    const novaData = dias === 0 ? null : new Date(Date.now() + dias * 86400000);
    const dataSSH = novaData ? novaData.toISOString().split('T')[0] : '-1';

    try {
        const ssh = await new ConexaoSSH().conectar();
        const comando = `sudo chage -E ${dataSSH} ${username}`;
        const { stderr } = await ssh.execCommand(comando);
        ssh.dispose();

        if (stderr) throw new Error(stderr);

        // Atualizar JSON local
        let usuarios = fs.existsSync(usuariosPath) ? JSON.parse(fs.readFileSync(usuariosPath, 'utf8')) : [];

        const index = usuarios.findIndex(u => u.username === username);
        const registro = {
            username,
            expira_em: novaData?.toISOString() || null,
            ultima_atualizacao: new Date().toISOString()
        };

        if (index !== -1) {
            usuarios[index] = { ...usuarios[index], ...registro };
        } else {
            registro.data_criacao = new Date().toISOString();
            usuarios.push(registro);
        }

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        const msg = dias === 0
            ? `♾️ *Expiração removida* do usuário \`${username}\`.`
            : `✅ *Validade atualizada*\n👤 \`${username}\`\n📅 Nova data: *${novaData.toLocaleDateString('pt-BR')}*`;

        await bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', ...estados[chatId].menuPrincipal });

        // Notificação ao ADM (opcional)
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(process.env.CHAT_ID_ADMIN, `📆 Validade alterada:\n👤 ${username}\n🔧 Por: @${from_username || 'desconhecido'}\n📅 Nova validade: ${dias === 0 ? 'Ilimitada' : novaData.toLocaleDateString('pt-BR')}`);
        }

    } catch (err) {
        await bot.sendMessage(chatId, `❌ Erro ao alterar data: ${err.message}`, estados[chatId].menuPrincipal);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        estados[chatId].bot.removeListener('message', estados[chatId].messageListener);
        delete estados[chatId];
    }
}
