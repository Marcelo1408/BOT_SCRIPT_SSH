const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosDir = path.join('/root/bot-ssh/data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarAlteracaoData(bot, chatId, menuPrincipal);
};

function iniciarAlteracaoData(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '👤 Digite o nome do usuário para alterar a data de expiração:')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const username = resposta.text?.trim() || '';
                
                if (!/^[a-z_][a-z0-9_-]{0,31}$/i.test(username)) {
                    bot.sendMessage(chatId, '❌ Nome inválido! Use 1-32 caracteres (letras, números, hífens ou _)', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].username = username.toLowerCase();
                verificarUsuario(chatId);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar usuário:', err);
            limparEstado(chatId);
        });
}

async function verificarUsuario(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];
    
    try {
        // Verifica no servidor via SSH
        const ssh = await new ConexaoSSH().conectar();
        const { stdout } = await ssh.execCommand(`id ${username} >/dev/null 2>&1 && echo "EXISTS" || echo "NOT_FOUND"`);
        ssh.dispose();
        
        if (stdout.includes('NOT_FOUND')) {
            throw new Error(`Usuário ${username} não encontrado no servidor`);
        }

        // Verifica no arquivo local
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
            const usuario = usuarios.find(u => u.username === username);
            
            if (usuario) {
                estados[chatId].dataAtual = usuario.expira_em || null;
            } else {
                await bot.sendMessage(chatId, '⚠️ Usuário encontrado no servidor mas não no registro local. Continuando...');
            }
        }

        estados[chatId].etapa = 'dias';
        solicitarNovosDias(bot, chatId, menuPrincipal);

    } catch (error) {
        console.error('Erro ao verificar usuário:', error);
        bot.sendMessage(
            chatId,
            `❌ ${error.message}\n\nVerifique o nome e tente novamente.`,
            menuPrincipal
        ).catch(console.error);
        limparEstado(chatId);
    }
}

function solicitarNovosDias(bot, chatId, menuPrincipal) {
    const { username, dataAtual } = estados[chatId];
    
    const formatarData = (iso) => iso ? new Date(iso).toLocaleDateString('pt-BR') : 'Sem expiração';
    const dataAtualFormatada = dataAtual ? formatarData(dataAtual) : 'Sem expiração';

    bot.sendMessage(
        chatId,
        `📅 Usuário: *${username}*\nData atual: *${dataAtualFormatada}*\n\nDigite os novos dias de acesso (número inteiro positivo):\n\nDigite 0 para remover a expiração`,
        { parse_mode: 'Markdown' }
    )
    .then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            const diasInput = resposta.text?.trim() || '';
            
            if (!/^-?\d+$/.test(diasInput)) {
                bot.sendMessage(chatId, '❌ Valor inválido! Digite apenas números inteiros.', menuPrincipal)
                    .then(() => limparEstado(chatId))
                    .catch(console.error);
                return;
            }

            const dias = parseInt(diasInput);
            if (dias < 0) {
                bot.sendMessage(chatId, '❌ O número de dias não pode ser negativo.', menuPrincipal)
                    .then(() => limparEstado(chatId))
                    .catch(console.error);
                return;
            }

            estados[chatId].dias = dias;
            alterarDataExpiracao(chatId);
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    })
    .catch(err => {
        console.error('Erro ao solicitar dias:', err);
        limparEstado(chatId);
    });
}

async function alterarDataExpiracao(chatId) {
    const { bot, menuPrincipal, username, dias, from_username } = estados[chatId];
    
    try {
        // 1. Preparar nova data de expiração
        const dataExpiracao = dias === 0 ? null : new Date(Date.now() + dias * 86400000);
        const dataFormatadaSSH = dias === 0 ? '' : dataExpiracao.toISOString().split('T')[0];
        
        // 2. Alterar data no servidor via SSH
        const ssh = await new ConexaoSSH().conectar();
        const comando = dias === 0 
            ? `sudo chage -E -1 ${username}`
            : `sudo chage -E ${dataFormatadaSSH} ${username}`;
        
        const { stderr } = await ssh.execCommand(comando);
        ssh.dispose();

        if (stderr) throw new Error(stderr);

        // 3. Atualizar arquivo JSON
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        const usuarioIndex = usuarios.findIndex(u => u.username === username);
        if (usuarioIndex !== -1) {
            usuarios[usuarioIndex] = {
                ...usuarios[usuarioIndex],
                expira_em: dataExpiracao?.toISOString() || null,
                ultima_atualizacao: new Date().toISOString()
            };
        } else {
            usuarios.push({
                username: username,
                data_criacao: new Date().toISOString(),
                expira_em: dataExpiracao?.toISOString() || null,
                ultima_atualizacao: new Date().toISOString()
            });
        }

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        // 4. Enviar confirmação
        const formatarData = (iso) => iso ? new Date(iso).toLocaleDateString('pt-BR') : 'Sem expiração';
        
        const mensagemSucesso = dias === 0
            ? `♾️ *Expiração removida!* O usuário \`${username}\` não terá data de expiração.`
            : `✅ *Validade atualizada!*\n\n` +
              `👤: \`${username}\`\n` +
              `📅 Nova validade: ${formatarData(dataExpiracao?.toISOString())}\n` +
              `⏳ Dias adicionados: ${dias}`;

        await bot.sendMessage(
            chatId,
            mensagemSucesso,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // Notificar admin
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `📅 Data de expiração alterada\n` +
                `👤 ${username}\n` +
                `🔄 ${dias === 0 ? 'Expiração removida' : `Nova data: ${formatarData(dataExpiracao?.toISOString())}`}\n` +
                `👤 Por: @${from_username || 'desconhecido'}`
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao alterar data de expiração:', error);
        await bot.sendMessage(
            chatId,
            `❌ Falha ao alterar data de expiração:\n${error.message}\n\nTente novamente.`,
            menuPrincipal
        ).catch(console.error);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        delete estados[chatId];
    }
}