const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

module.exports = async (bot, msg, menuPrincipal) => {
    const chatId = msg.chat.id;
    const usuariosPath = path.join(__dirname, '../data/usuarios.json');

    try {
        // Verifica se o arquivo existe
        if (!fs.existsSync(usuariosPath)) {
            return bot.sendMessage(chatId, '❌ Nenhum usuário cadastrado ainda.', menuPrincipal);
        }

        // Carrega os usuários
        let usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        const agora = new Date();

        // Filtra usuários expirados
        let expirados = usuarios.filter(usuario => {
            return new Date(usuario.expira_em) < agora;
        });

        if (expirados.length === 0) {
            return bot.sendMessage(chatId, '✅ Nenhum usuário expirado encontrado.', menuPrincipal);
        }

        // Formata a mensagem
        let mensagem = '🔴 *Usuários Expirados:*\n\n';
        expirados.forEach((usuario, index) => {
            const dataExpiracao = new Date(usuario.expira_em).toLocaleDateString('pt-BR');
            const diasAtraso = Math.floor((agora - new Date(usuario.expira_em)) / (1000 * 60 * 60 * 24));
            
            mensagem += `▫️ *${usuario.username}*\n` +
                       `📅 Expirou em: ${dataExpiracao}\n` +
                       `⏳ Atraso: ${diasAtraso} dias\n` +
                       (index < expirados.length - 1 ? '\n' : '');
        });

        // Envia a listagem
        await bot.sendMessage(
            chatId,
            mensagem,
            {
                parse_mode: 'Markdown',
                disable_web_page_preview: true
            }
        );

        // Pergunta sobre remoção
        await bot.sendMessage(
            chatId,
            `⚠️ *Deseja remover TODOS os ${expirados.length} usuários expirados?*\n\n` +
            `❗ Esta ação é *irreversível* e removerá permanentemente todas as contas listadas!`,
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    keyboard: [
                        [{ text: '✅ SIM, REMOVER TUDO' }],
                        [{ text: '❌ Cancelar' }]
                    ],
                    resize_keyboard: true,
                    one_time_keyboard: true
                }
            }
        );

        // Listener para a resposta
        const listener = async (resposta) => {
            if (resposta.chat.id !== chatId) return;

            bot.removeListener('message', listener);

            if (resposta.text?.toLowerCase().includes('remover')) {
                await bot.sendMessage(chatId, '⏳ Removendo usuários expirados, por favor aguarde...');

                let ssh;
                let removidosComSucesso = 0;
                let falhas = 0;
                const usuariosRemovidos = [];

                try {
                    // Cria nova instância SSH e conecta
                    ssh = new ConexaoSSH();
                    const conexao = await ssh.conectar();
                    
                    if (!conexao) {
                        throw new Error('Falha ao conectar ao servidor SSH');
                    }

                    // Processa cada usuário expirado
                    for (const usuario of expirados) {
                        try {
                            // Verifica se o usuário existe
                            const { stdout } = await conexao.execCommand(`id ${usuario.username} &>/dev/null && echo "EXISTS" || echo "NOT_FOUND"`);
                            
                            if (stdout.trim() === 'EXISTS') {
                                // Remove do sistema
                                await conexao.execCommand(`sudo userdel -r ${usuario.username}`);
                                console.log(`Usuário ${usuario.username} removido do sistema`);
                                
                                // Marca para remoção do JSON
                                usuariosRemovidos.push(usuario.username);
                                removidosComSucesso++;
                            } else {
                                console.log(`Usuário ${usuario.username} não encontrado no sistema`);
                                falhas++;
                            }
                        } catch (error) {
                            console.error(`Falha ao remover ${usuario.username}:`, error);
                            falhas++;
                        }
                    }

                    // Atualiza a lista de usuários
                    usuarios = usuarios.filter(u => !usuariosRemovidos.includes(u.username));
                    
                    // Salva o arquivo JSON atualizado
                    fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
                    console.log('Arquivo JSON atualizado com sucesso');

                    // Mensagem de resultado
                    let resultadoMsg = `✅ *${removidosComSucesso} usuários removidos com sucesso!*`;
                    if (falhas > 0) {
                        resultadoMsg += `\n\n❌ ${falhas} usuários não puderam ser removidos.`;
                    }

                    await bot.sendMessage(
                        chatId,
                        resultadoMsg,
                        { parse_mode: 'Markdown', ...menuPrincipal }
                    );

                } catch (error) {
                    console.error('Erro durante o processo:', error);
                    await bot.sendMessage(
                        chatId,
                        `❌ Erro durante a remoção: ${error.message}`,
                        menuPrincipal
                    );
                } finally {
                    if (ssh && conexao) {
                        try {
                            await ssh.desconectar();
                        } catch (err) {
                            console.error('Erro ao desconectar SSH:', err);
                        }
                    }
                }
            } else {
                await bot.sendMessage(
                    chatId,
                    '⚠️ Operação cancelada. Nenhum usuário foi removido.',
                    menuPrincipal
                );
            }
        };

        bot.once('message', listener);

    } catch (error) {
        console.error('Erro:', error);
        await bot.sendMessage(
            chatId,
            `❌ Erro ao processar usuários expirados:\n${error.message}`,
            menuPrincipal
        );
    }
};