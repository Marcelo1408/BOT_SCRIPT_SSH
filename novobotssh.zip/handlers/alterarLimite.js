const fs = require('fs').promises;
const path = require('path');
const conectarSSH = require('../utils/conexaoSSH'); // Mantendo seu padrão de importação

module.exports = async (bot, msg, menuPrincipal) => {
    const chatId = msg.chat.id;
    let ssh = null;

    try {
        // 1. Solicitar nome de usuário
        await bot.sendMessage(chatId, '👤 Digite o nome do usuário para alterar o limite:', {
            reply_markup: { force_reply: true }
        });

        // 2. Aguardar resposta com timeout
        const username = await waitForReply(bot, chatId, 'nome do usuário');
        
        // 3. Verificar usuário
        const usuariosPath = path.join(__dirname, '../data/usuarios.json');
        const usuarios = JSON.parse(await fs.readFile(usuariosPath));
        const usuario = usuarios.find(u => u.username === username);

        if (!usuario) {
            return bot.sendMessage(chatId, `❌ Usuário "${username}" não encontrado.`, menuPrincipal);
        }

        // 4. Solicitar novo limite
        await bot.sendMessage(
            chatId,
            `🔢 Usuário: *${username}*\nLimite atual: *${usuario.limite_conexoes || 'não definido'}*\n\nDigite o novo limite:`,
            { 
                parse_mode: 'Markdown',
                reply_markup: { force_reply: true } 
            }
        );

        // 5. Aguardar novo limite
        const novoLimiteText = await waitForReply(bot, chatId, 'novo limite');
        const novoLimite = parseInt(novoLimiteText);
        
        if (isNaN(novoLimite)) {
            return bot.sendMessage(chatId, '❌ Por favor, digite um número válido.', menuPrincipal);
        }

        if (novoLimite <= 0) {
            return bot.sendMessage(chatId, '❌ O limite deve ser maior que zero.', menuPrincipal);
        }

        // 6. Conectar SSH usando sua função existente
        ssh = await conectarSSH();

        // 7. Executar comandos SSH
        const commands = [
            `sudo sed -i '/^${username} hard maxlogins/d' /etc/security/limits.conf`,
            `echo "${username} hard maxlogins ${novoLimite}" | sudo tee -a /etc/security/limits.conf`
        ];

        for (const cmd of commands) {
            const result = await ssh.execCommand(cmd);
            if (result.stderr && !result.stderr.includes('no matches found')) {
                throw new Error(result.stderr);
            }
        }

        // 8. Atualizar localmente
        const usuarioIndex = usuarios.findIndex(u => u.username === username);
        if (usuarioIndex !== -1) {
            usuarios[usuarioIndex].limite_conexoes = novoLimite;
            await fs.writeFile(usuariosPath, JSON.stringify(usuarios, null, 2));
        }

        // 9. Confirmar com usuário
        await bot.sendMessage(
            chatId,
            `✅ *Limite alterado com sucesso!*\n\n` +
            `👤 Usuário: *${username}*\n` +
            `🔢 Novo limite: *${novoLimite}* conexões simultâneas`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

    } catch (error) {
        console.error('Erro em alterarLimite:', error);
        
        let errorMessage = '❌ Ocorreu um erro ao processar sua solicitação';
        if (error.message.includes('timeout')) {
            errorMessage = '⌛ Tempo de espera excedido. Tente novamente.';
        } else if (error.message.includes('Authentication')) {
            errorMessage = '🔒 Erro de autenticação no servidor SSH';
        } else if (error.message.includes('Variáveis faltando')) {
            errorMessage = '⚠️ Configuração incompleta do servidor';
        }

        await bot.sendMessage(
            chatId,
            `${errorMessage}\n\nDetalhes: ${error.message}`,
            menuPrincipal
        );
    } finally {
        if (ssh) {
            try {
                await ssh.dispose();
            } catch (disconnectError) {
                console.error('Erro ao desconectar SSH:', disconnectError);
            }
        }
    }
};

// Função auxiliar para aguardar resposta (mantida igual)
function waitForReply(bot, chatId, prompt) {
    return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            bot.removeListener('message', replyHandler);
            reject(new Error(`Timeout aguardando ${prompt}`));
        }, 300000); // 5 minutos timeout

        const replyHandler = (replyMsg) => {
            if (replyMsg.chat.id === chatId && 
                replyMsg.reply_to_message && 
                replyMsg.reply_to_message.text.includes(prompt)) {
                clearTimeout(timeout);
                bot.removeListener('message', replyHandler);
                resolve(replyMsg.text.trim());
            }
        };

        bot.on('message', replyHandler);
    });
}