const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosDir = path.join('/root/bot-ssh/data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarAlteracaoLimite(bot, chatId, menuPrincipal);
};

function iniciarAlteracaoLimite(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '👤 Digite o nome do usuário para alterar o limite de conexões:')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const username = resposta.text?.trim() || '';
                
                if (username.length < 3) {
                    bot.sendMessage(chatId, '❌ Nome de usuário inválido. Mínimo 3 caracteres.', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].username = username.toLowerCase();
                verificarUsuario(chatId);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar usuário:', err);
            limparEstado(chatId);
        });
}

async function verificarUsuario(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];
    
    try {
        // Verifica no arquivo local
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        const usuario = usuarios.find(u => u.username === username);
        if (!usuario) {
            throw new Error(`Usuário ${username} não encontrado`);
        }

        estados[chatId].limiteAtual = usuario.limite_conexoes || 1;
        solicitarNovoLimite(bot, chatId, menuPrincipal);

    } catch (error) {
        console.error('Erro ao verificar usuário:', error);
        bot.sendMessage(
            chatId,
            `❌ ${error.message}\n\nVerifique o nome e tente novamente.`,
            menuPrincipal
        ).catch(console.error);
        limparEstado(chatId);
    }
}

function solicitarNovoLimite(bot, chatId, menuPrincipal) {
    const { username, limiteAtual } = estados[chatId];

    bot.sendMessage(
        chatId,
        `🔢 Usuário: *${username}*\nLimite atual: *${limiteAtual}*\n\nDigite o novo limite (1-10):`,
        { parse_mode: 'Markdown' }
    )
    .then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            const novoLimite = parseInt(resposta.text?.trim() || 0);
            
            if (isNaN(novoLimite) || novoLimite < 1 || novoLimite > 10) {
                bot.sendMessage(chatId, '❌ Limite inválido. Digite um número entre 1 e 10.', menuPrincipal)
                    .then(() => limparEstado(chatId))
                    .catch(console.error);
                return;
            }

            estados[chatId].novoLimite = novoLimite;
            alterarLimiteSSH(chatId);
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    })
    .catch(err => {
        console.error('Erro ao solicitar limite:', err);
        limparEstado(chatId);
    });
}

async function alterarLimiteSSH(chatId) {
    const { bot, menuPrincipal, username, novoLimite, from_username } = estados[chatId];
    
    try {
        // 1. Alterar limite no sistema
        const ssh = await new ConexaoSSH().conectar();
        
        // Remove configuração existente
        await ssh.execCommand(`sudo sed -i '/^${username} hard maxlogins/d' /etc/security/limits.conf`);
        
        // Adiciona nova configuração
        const { stderr } = await ssh.execCommand(
            `echo "${username} hard maxlogins ${novoLimite}" | sudo tee -a /etc/security/limits.conf`
        );
        
        if (stderr && !stderr.includes('no matches found')) {
            throw new Error(stderr);
        }

        ssh.dispose();

        // 2. Atualizar arquivo JSON
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        const usuarioIndex = usuarios.findIndex(u => u.username === username);
        if (usuarioIndex !== -1) {
            usuarios[usuarioIndex].limite_conexoes = novoLimite;
            usuarios[usuarioIndex].ultima_alteracao = new Date().toISOString();
            fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
        }

        // 3. Enviar confirmação
        await bot.sendMessage(
            chatId,
            `✅ *Limite alterado com sucesso!*\n\n` +
            `👤 Usuário: \`${username}\`\n` +
            `🔢 Novo limite: \`${novoLimite}\` conexões simultâneas`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // Notificar admin
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `🔢 Limite alterado\n` +
                `👤 ${username}\n` +
                `🔄 Novo limite: ${novoLimite}\n` +
                `👤 Por: @${from_username || 'desconhecido'}`
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao alterar limite:', error);
        await bot.sendMessage(
            chatId,
            `❌ Falha ao alterar limite:\n${error.message}\n\nTente novamente.`,
            menuPrincipal
        ).catch(console.error);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        delete estados[chatId];
    }
}