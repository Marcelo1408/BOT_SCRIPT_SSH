const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

// Configuração de caminhos padronizada
const usuariosDir = path.join('/root', 'bot', 'data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

// Garante que o diretório existe
if (!fs.existsSync(usuariosDir)) {
    fs.mkdirSync(usuariosDir, { recursive: true });
}

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarAlteracaoLimite(bot, chatId, menuPrincipal);
};

function iniciarAlteracaoLimite(bot, chatId, menuPrincipal) {
    // Carrega a lista de usuários para sugestão
    let usuarios = [];
    if (fs.existsSync(usuariosPath)) {
        try {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        } catch (err) {
            console.error('Erro ao ler arquivo de usuários:', err);
        }
    }

    const sugestoes = usuarios.length > 0 
        ? `\n\n📋 Usuários existentes:\n${usuarios.map(u => `- ${u.username}`).join('\n')}`
        : '\n\nℹ️ Nenhum usuário registrado ainda.';

    bot.sendMessage(
        chatId,
        `👤 *Digite o nome do usuário* para alterar o limite de conexões:${sugestoes}`,
        { parse_mode: 'Markdown' }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            // Padroniza a entrada do usuário (remove espaços e converte para minúsculas)
            const usernameInput = resposta.text?.trim().toLowerCase().replace(/\s+/g, '');

            // Busca case-insensitive no array de usuários
            const usuarioEncontrado = usuarios.find(u => 
                u.username.toLowerCase() === usernameInput
            );

            if (!usuarioEncontrado) {
                bot.sendMessage(
                    chatId,
                    '❌ *Usuário não encontrado!*\n\nVerifique o nome e tente novamente.',
                    { parse_mode: 'Markdown', ...menuPrincipal }
                ).then(() => limparEstado(chatId))
                 .catch(console.error);
                return;
            }

            // Armazena o username exatamente como está no sistema (mantendo case original)
            estados[chatId].username = usuarioEncontrado.username;
            estados[chatId].usuarioData = usuarioEncontrado;
            verificarUsuarioNoServidor(chatId);
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro ao solicitar usuário:', err);
        limparEstado(chatId);
    });
}

async function verificarUsuarioNoServidor(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];

    try {
        // Verifica se o usuário existe no sistema SSH
        const ssh = await new ConexaoSSH().conectar();
        const { stdout, stderr } = await ssh.execCommand(`id -u ${username} 2>/dev/null || echo "NOT_FOUND"`);
        ssh.dispose();

        if (stdout.trim() === "NOT_FOUND" || stderr) {
            throw new Error(`Usuário "${username}" não existe no servidor SSH`);
        }

        // Armazena o limite atual para referência
        estados[chatId].limiteAtual = estados[chatId].usuarioData.limite_conexoes || 1;
        solicitarNovoLimite(bot, chatId, menuPrincipal);

    } catch (error) {
        console.error('Erro ao verificar usuário:', error);
        bot.sendMessage(
            chatId,
            `❌ *Erro na verificação:*\n${error.message}\n\nPor favor, tente novamente.`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        ).catch(console.error);
        limparEstado(chatId);
    }
}

function solicitarNovoLimite(bot, chatId, menuPrincipal) {
    const { username, limiteAtual } = estados[chatId];

    bot.sendMessage(
        chatId,
        `🔢 *Alteração de Limite*\n\n` +
        `👤 Usuário: \`${username}\`\n` +
        `📊 Limite atual: \`${limiteAtual}\` conexões\n\n` +
        `Digite o *novo limite* de conexões simultâneas (1-10):`,
        { parse_mode: 'Markdown' }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            const novoLimite = parseInt(resposta.text?.trim());

            if (isNaN(novoLimite) || novoLimite < 1 || novoLimite > 10) {
                bot.sendMessage(
                    chatId,
                    '❌ *Valor inválido!*\n\nO limite deve ser um número entre 1 e 10.',
                    { parse_mode: 'Markdown', ...menuPrincipal }
                ).then(() => limparEstado(chatId))
                 .catch(console.error);
                return;
            }

            estados[chatId].novoLimite = novoLimite;
            confirmarAlteracaoLimite(chatId);
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro ao solicitar novo limite:', err);
        limparEstado(chatId);
    });
}

function confirmarAlteracaoLimite(chatId) {
    const { bot, menuPrincipal, username, limiteAtual, novoLimite } = estados[chatId];

    bot.sendMessage(
        chatId,
        `⚠️ *Confirmação de Alteração*\n\n` +
        `👤 Usuário: \`${username}\`\n` +
        `🔢 Limite atual: \`${limiteAtual}\` → Novo limite: \`${novoLimite}\`\n\n` +
        `Deseja confirmar esta alteração?`,
        {
            parse_mode: 'Markdown',
            reply_markup: {
                keyboard: [
                    [{ text: '✅ Sim, confirmar' }],
                    [{ text: '❌ Cancelar' }]
                ],
                resize_keyboard: true,
                one_time_keyboard: true
            }
        }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            if (resposta.text?.toLowerCase().includes('confirmar')) {
                alterarLimiteNoServidor(chatId);
            } else {
                bot.sendMessage(
                    chatId,
                    '⚠️ Alteração cancelada pelo usuário.',
                    menuPrincipal
                ).catch(console.error);
                limparEstado(chatId);
            }
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro na confirmação:', err);
        limparEstado(chatId);
    });
}

async function alterarLimiteNoServidor(chatId) {
    const { bot, menuPrincipal, username, novoLimite, usuarioData, from_username } = estados[chatId];

    try {
        // 1. Atualiza no servidor SSH
        const ssh = await new ConexaoSSH().conectar();
        
        // Remove configuração anterior
        await ssh.execCommand(`sudo sed -i '/^${username} hard maxlogins/d' /etc/security/limits.conf`);
        
        // Adiciona novo limite
        const { stderr } = await ssh.execCommand(
            `echo "${username} hard maxlogins ${novoLimite}" | sudo tee -a /etc/security/limits.conf`
        );
        
        ssh.dispose();

        if (stderr && !stderr.includes('password updated successfully')) {
            throw new Error(`Erro SSH: ${stderr}`);
        }

        // 2. Atualiza o arquivo local
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        const usuarioIndex = usuarios.findIndex(u => u.username === username);
        if (usuarioIndex !== -1) {
            usuarios[usuarioIndex].limite_conexoes = novoLimite;
            usuarios[usuarioIndex].ultima_alteracao = new Date().toISOString();
            usuarios[usuarioIndex].alterado_por = from_username || 'sistema';
        } else {
            // Se não encontrou, adiciona como novo registro (backup)
            usuarios.push({
                ...usuarioData,
                limite_conexoes: novoLimite,
                ultima_alteracao: new Date().toISOString(),
                alterado_por: from_username || 'sistema'
            });
        }

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        // 3. Notifica o usuário
        await bot.sendMessage(
            chatId,
            `✅ *Limite atualizado com sucesso!*\n\n` +
            `👤 Usuário: \`${username}\`\n` +
            `🔢 Novo limite: \`${novoLimite}\` conexões simultâneas\n\n` +
            `As alterações podem levar alguns minutos para surtir efeito.`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // 4. Notifica o admin (se configurado)
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `🔢 *Alteração de Limite SSH*\n\n` +
                `👤 Usuário: ${username}\n` +
                `🔄 Novo limite: ${novoLimite}\n` +
                `👤 Alterado por: @${from_username || 'sistema'}\n` +
                `⏱️ ${new Date().toLocaleString()}`,
                { parse_mode: 'Markdown' }
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao alterar limite:', error);
        await bot.sendMessage(
            chatId,
            `❌ *Falha na alteração!*\n\n` +
            `Erro: ${error.message}\n\n` +
            `Por favor, tente novamente ou contate o suporte.`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        ).catch(console.error);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        // Remove todos os listeners registrados
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        
        // Limpa o estado
        delete estados[chatId];
    }
}