const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosDir = path.join('/root/bot-ssh/data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarAlteracaoLimite(bot, chatId, menuPrincipal);
};

function iniciarAlteracaoLimite(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '👤 Digite o nome do usuário para alterar o limite de conexões:')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const username = resposta.text?.trim().toLowerCase();

                if (!/^[a-z_][a-z0-9_-]{2,31}$/i.test(username)) {
                    bot.sendMessage(chatId, '❌ Nome de usuário inválido. Use de 3 a 32 caracteres.', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].username = username;
                verificarUsuario(chatId);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar usuário:', err);
            limparEstado(chatId);
        });
}

async function verificarUsuario(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];

    try {
        // Verifica se o usuário existe via SSH
        const ssh = await new ConexaoSSH().conectar();
        const { stdout } = await ssh.execCommand(`id ${username} >/dev/null 2>&1 && echo "EXISTS" || echo "NOT_FOUND"`);
        ssh.dispose();

        if (!stdout.includes('EXISTS')) {
            throw new Error(`Usuário ${username} não encontrado no servidor.`);
        }

        // Verifica no arquivo JSON local
        let usuarios = fs.existsSync(usuariosPath)
            ? JSON.parse(fs.readFileSync(usuariosPath, 'utf8'))
            : [];

        const usuario = usuarios.find(u => u.username === username);
        estados[chatId].limiteAtual = usuario?.limite_conexoes || 1;

        solicitarNovoLimite(bot, chatId, menuPrincipal);

    } catch (error) {
        console.error('Erro ao verificar usuário:', error);
        bot.sendMessage(
            chatId,
            `❌ ${error.message}\n\nVerifique o nome e tente novamente.`,
            menuPrincipal
        ).catch(console.error);
        limparEstado(chatId);
    }
}

function solicitarNovoLimite(bot, chatId, menuPrincipal) {
    const { username, limiteAtual } = estados[chatId];

    bot.sendMessage(
        chatId,
        `🔢 Usuário: *${username}*\nLimite atual: *${limiteAtual}*\n\nDigite o novo limite de conexões simultâneas (1 a 10):`,
        { parse_mode: 'Markdown' }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            const novoLimite = parseInt(resposta.text?.trim());

            if (isNaN(novoLimite) || novoLimite < 1 || novoLimite > 10) {
                bot.sendMessage(chatId, '❌ Limite inválido. Digite um número de 1 a 10.', menuPrincipal)
                    .then(() => limparEstado(chatId))
                    .catch(console.error);
                return;
            }

            estados[chatId].novoLimite = novoLimite;
            alterarLimiteSSH(chatId);
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro ao solicitar limite:', err);
        limparEstado(chatId);
    });
}

async function alterarLimiteSSH(chatId) {
    const { bot, menuPrincipal, username, novoLimite, from_username } = estados[chatId];

    try {
        const ssh = await new ConexaoSSH().conectar();

        // Remove configuração anterior e adiciona nova
        await ssh.execCommand(`sudo sed -i '/^${username} hard maxlogins/d' /etc/security/limits.conf`);
        const { stderr } = await ssh.execCommand(
            `echo "${username} hard maxlogins ${novoLimite}" | sudo tee -a /etc/security/limits.conf`
        );

        ssh.dispose();

        if (stderr && !stderr.includes('no matches')) {
            throw new Error(stderr);
        }

        // Atualiza arquivo local
        let usuarios = fs.existsSync(usuariosPath)
            ? JSON.parse(fs.readFileSync(usuariosPath, 'utf8'))
            : [];

        const index = usuarios.findIndex(u => u.username === username);
        if (index !== -1) {
            usuarios[index].limite_conexoes = novoLimite;
            usuarios[index].ultima_alteracao = new Date().toISOString();
        } else {
            usuarios.push({
                username,
                limite_conexoes: novoLimite,
                data_criacao: new Date().toISOString(),
                ultima_alteracao: new Date().toISOString()
            });
        }

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        // Confirmação ao usuário
        await bot.sendMessage(
            chatId,
            `✅ *Limite atualizado com sucesso!*\n\n👤 Usuário: \`${username}\`\n🔢 Novo limite: \`${novoLimite}\` conexões`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // Notifica o admin
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `🔢 Limite de conexões alterado\n👤 ${username}\n🔄 Novo limite: ${novoLimite}\n👤 Alterado por: @${from_username || 'desconhecido'}`
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao alterar limite:', error);
        await bot.sendMessage(
            chatId,
            `❌ Erro ao alterar limite:\n${error.message}\n\nTente novamente.`,
            menuPrincipal
        ).catch(console.error);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        delete estados[chatId];
    }
}
