const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosDir = path.join('/root/bot-ssh/data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarAlteracaoSenha(bot, chatId, menuPrincipal);
};

function iniciarAlteracaoSenha(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '🔢 Digite o nome do usuário que deseja alterar a senha:')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const username = resposta.text?.trim() || '';
                
                if (username.length < 3) {
                    bot.sendMessage(chatId, '❌ Nome de usuário inválido. Mínimo 3 caracteres.', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].username = username.toLowerCase();
                solicitarNovaSenha(bot, chatId, menuPrincipal);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar usuário:', err);
            limparEstado(chatId);
        });
}

function solicitarNovaSenha(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '🔑 Digite a NOVA senha (mínimo 4 caracteres):')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const novaSenha = resposta.text?.trim() || '';
                
                if (novaSenha.length < 4) {
                    bot.sendMessage(chatId, '❌ Senha muito curta. Mínimo 4 caracteres.', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].novaSenha = novaSenha;
                confirmarAlteracaoSenha(chatId);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar senha:', err);
            limparEstado(chatId);
        });
}

async function confirmarAlteracaoSenha(chatId) {
    const { bot, menuPrincipal, username, novaSenha, from_username } = estados[chatId];
    
    try {
        // 1. Alterar senha no sistema
        const ssh = await new ConexaoSSH().conectar();
        
        // Verifica se usuário existe
        const { stdout } = await ssh.execCommand(`id -u ${username} 2>/dev/null`);
        if (!stdout.trim()) {
            throw new Error(`Usuário ${username} não encontrado`);
        }

        // Comando para alterar senha
        const comando = `echo "${username}:${novaSenha}" | sudo chpasswd`;
        const { stderr } = await ssh.execCommand(comando);
        
        if (stderr && !stderr.includes('password updated successfully')) {
            throw new Error(stderr);
        }

        ssh.dispose();

        // 2. Atualizar arquivo JSON
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        const usuarioIndex = usuarios.findIndex(u => u.username === username);
        if (usuarioIndex !== -1) {
            usuarios[usuarioIndex].senha = novaSenha;
            usuarios[usuarioIndex].ultima_alteracao = new Date().toISOString();
            fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
        }

        // 3. Enviar confirmação
        await bot.sendMessage(
            chatId,
            `✅ *Senha alterada com sucesso!*\n\n` +
            `👤 Usuário: \`${username}\`\n` +
            `🔑 Nova senha: \`${novaSenha}\``,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // Notificar admin
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `🔐 Senha alterada\n` +
                `👤 ${username}\n` +
                `🔄 Por: @${from_username || 'desconhecido'}`
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao alterar senha:', error);
        await bot.sendMessage(
            chatId,
            `❌ Falha ao alterar senha:\n${error.message}\n\nTente novamente.`,
            menuPrincipal
        ).catch(console.error);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        delete estados[chatId];
    }
}