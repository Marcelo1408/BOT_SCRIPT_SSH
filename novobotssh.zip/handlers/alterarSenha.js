const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

// Configuração de caminhos padronizada
const usuariosDir = path.join('/root', 'bot', 'data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

// Garante que o diretório existe
if (!fs.existsSync(usuariosDir)) {
    fs.mkdirSync(usuariosDir, { recursive: true });
}

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarAlteracaoSenha(bot, chatId, menuPrincipal);
};

function iniciarAlteracaoSenha(bot, chatId, menuPrincipal) {
    // Carrega lista de usuários para sugestão
    let usuarios = [];
    if (fs.existsSync(usuariosPath)) {
        try {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        } catch (err) {
            console.error('Erro ao ler arquivo de usuários:', err);
        }
    }

    const sugestoes = usuarios.length > 0 
        ? `\n\n📋 Usuários existentes:\n${usuarios.map(u => `- ${u.username}`).join('\n')}`
        : '\n\nℹ️ Nenhum usuário registrado ainda.';

    bot.sendMessage(
        chatId,
        `👤 *Digite o nome do usuário* para alterar a senha:${sugestoes}`,
        { parse_mode: 'Markdown' }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            // Padroniza a entrada do usuário (remove espaços e converte para minúsculas)
            const usernameInput = resposta.text?.trim().toLowerCase().replace(/\s+/g, '');

            // Busca case-insensitive no array de usuários
            const usuarioEncontrado = usuarios.find(u => 
                u.username.toLowerCase() === usernameInput
            );

            if (!usuarioEncontrado) {
                bot.sendMessage(
                    chatId,
                    '❌ *Usuário não encontrado!*\n\nVerifique o nome e tente novamente.',
                    { parse_mode: 'Markdown', ...menuPrincipal }
                ).then(() => limparEstado(chatId))
                 .catch(console.error);
                return;
            }

            // Armazena o username exatamente como está no sistema (mantendo case original)
            estados[chatId].username = usuarioEncontrado.username;
            estados[chatId].usuarioData = usuarioEncontrado;
            verificarUsuarioNoServidor(chatId);
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro ao solicitar usuário:', err);
        limparEstado(chatId);
    });
}

async function verificarUsuarioNoServidor(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];

    try {
        // Verifica se o usuário existe no sistema SSH
        const ssh = await new ConexaoSSH().conectar();
        const { stdout, stderr } = await ssh.execCommand(`id -u ${username} 2>/dev/null || echo "NOT_FOUND"`);
        ssh.dispose();

        if (stdout.trim() === "NOT_FOUND" || stderr) {
            throw new Error(`Usuário "${username}" não existe no servidor SSH`);
        }

        solicitarNovaSenha(bot, chatId, menuPrincipal);

    } catch (error) {
        console.error('Erro ao verificar usuário:', error);
        bot.sendMessage(
            chatId,
            `❌ *Erro na verificação:*\n${error.message}\n\nPor favor, tente novamente.`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        ).catch(console.error);
        limparEstado(chatId);
    }
}

function solicitarNovaSenha(bot, chatId, menuPrincipal) {
    bot.sendMessage(
        chatId,
        '🔑 *Digite a NOVA senha* (mínimo 4 caracteres):',
        { parse_mode: 'Markdown' }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            const novaSenha = resposta.text?.trim() || '';
            
            if (novaSenha.length < 4) {
                bot.sendMessage(
                    chatId,
                    '❌ *Senha muito curta!*\n\nMínimo 4 caracteres.',
                    { parse_mode: 'Markdown', ...menuPrincipal }
                ).then(() => limparEstado(chatId))
                 .catch(console.error);
                return;
            }

            estados[chatId].novaSenha = novaSenha;
            confirmarAlteracaoSenha(chatId);
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro ao solicitar senha:', err);
        limparEstado(chatId);
    });
}

function confirmarAlteracaoSenha(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];

    bot.sendMessage(
        chatId,
        `⚠️ *Confirmar alteração de senha?*\n\n` +
        `👤 Usuário: \`${username}\`\n` +
        `🔑 Nova senha: \`${estados[chatId].novaSenha}\``,
        {
            parse_mode: 'Markdown',
            reply_markup: {
                keyboard: [
                    [{ text: '✅ Sim, confirmar' }],
                    [{ text: '❌ Cancelar' }]
                ],
                resize_keyboard: true,
                one_time_keyboard: true
            }
        }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            if (resposta.text?.toLowerCase().includes('confirmar')) {
                alterarSenhaNoServidor(chatId);
            } else {
                bot.sendMessage(
                    chatId,
                    '⚠️ Alteração cancelada pelo usuário.',
                    menuPrincipal
                ).catch(console.error);
                limparEstado(chatId);
            }
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro na confirmação:', err);
        limparEstado(chatId);
    });
}

async function alterarSenhaNoServidor(chatId) {
    const { bot, menuPrincipal, username, novaSenha, usuarioData, from_username } = estados[chatId];

    try {
        // 1. Alterar senha no servidor SSH
        const ssh = await new ConexaoSSH().conectar();
        
        const { stderr } = await ssh.execCommand(
            `echo "${username}:${novaSenha}" | sudo chpasswd`
        );
        
        ssh.dispose();

        if (stderr && !stderr.includes('password updated successfully')) {
            throw new Error(`Erro SSH: ${stderr}`);
        }

        // 2. Atualiza o arquivo local
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        const usuarioIndex = usuarios.findIndex(u => u.username === username);
        if (usuarioIndex !== -1) {
            usuarios[usuarioIndex].senha = novaSenha;
            usuarios[usuarioIndex].ultima_alteracao = new Date().toISOString();
            usuarios[usuarioIndex].alterado_por = from_username || 'sistema';
        } else {
            // Se não encontrou, adiciona como novo registro (backup)
            usuarios.push({
                ...usuarioData,
                senha: novaSenha,
                ultima_alteracao: new Date().toISOString(),
                alterado_por: from_username || 'sistema'
            });
        }

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        // 3. Notifica o usuário
        await bot.sendMessage(
            chatId,
            `✅ *Senha alterada com sucesso!*\n\n` +
            `👤 Usuário: \`${username}\`\n` +
            `🔑 Nova senha: \`${novaSenha}\``,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // 4. Notifica o admin (se configurado)
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `🔐 *Senha alterada*\n\n` +
                `👤 Usuário: ${username}\n` +
                `👤 Alterado por: @${from_username || 'sistema'}\n` +
                `⏱️ ${new Date().toLocaleString()}`,
                { parse_mode: 'Markdown' }
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao alterar senha:', error);
        await bot.sendMessage(
            chatId,
            `❌ *Falha na alteração!*\n\n` +
            `Erro: ${error.message}\n\n` +
            `Por favor, tente novamente ou contate o suporte.`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        ).catch(console.error);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        // Remove todos os listeners registrados
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        
        // Limpa o estado
        delete estados[chatId];
    }
}