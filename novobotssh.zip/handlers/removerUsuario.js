const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

// Configuração de caminhos
const usuariosDir = path.join('/root', 'bot', 'data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

// Garante que o diretório existe
if (!fs.existsSync(usuariosDir)) {
    fs.mkdirSync(usuariosDir, { recursive: true });
}

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username,
        timestamp: Date.now()
    };

    // Timeout para limpeza automática após 5 minutos
    estados[chatId].timeout = setTimeout(() => {
        if (estados[chatId]) {
            bot.sendMessage(chatId, '⌛ Tempo de inatividade excedido. Operação cancelada.', menuPrincipal)
                .catch(console.error);
            limparEstado(chatId);
        }
    }, 300000);

    iniciarRemocaoUsuario(bot, chatId, menuPrincipal);
};

function iniciarRemocaoUsuario(bot, chatId, menuPrincipal) {
    // Carrega lista de usuários
    let usuarios = [];
    if (fs.existsSync(usuariosPath)) {
        try {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        } catch (err) {
            console.error('Erro ao ler arquivo de usuários:', err);
            return bot.sendMessage(
                chatId,
                '❌ Erro ao carregar lista de usuários. Tente novamente mais tarde.',
                menuPrincipal
            ).catch(console.error);
        }
    }

    // Filtra usuários ativos
    const usuariosAtivos = usuarios.filter(u => u.status !== 'bloqueado');
    const sugestoes = usuariosAtivos.length > 0 
        ? `\n\n📋 Usuários disponíveis:\n${usuariosAtivos.map(u => `- ${u.username}`).join('\n')}`
        : '\n\nℹ️ Nenhum usuário disponível encontrado.';

    bot.sendMessage(
        chatId,
        `❌ *Digite o nome do usuário* que deseja remover:${sugestoes}`,
        { 
            parse_mode: 'Markdown',
            reply_markup: {
                keyboard: usuariosAtivos.slice(0, 3).map(u => [{ text: u.username }]),
                resize_keyboard: true,
                one_time_keyboard: true
            }
        }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            const usernameInput = resposta.text?.trim();

            // Validação simplificada - aceita qualquer nome não vazio
            if (!usernameInput || usernameInput.length === 0) {
                return bot.sendMessage(
                    chatId,
                    '❌ *Nome inválido!* Digite um nome de usuário válido.',
                    { parse_mode: 'Markdown', ...menuPrincipal }
                ).then(() => limparEstado(chatId))
                 .catch(console.error);
            }

            // Busca exata (case sensitive)
            const usuarioEncontrado = usuarios.find(u => u.username === usernameInput);

            if (!usuarioEncontrado) {
                return bot.sendMessage(
                    chatId,
                    '❌ *Usuário não encontrado!*\n\nVerifique o nome e tente novamente.',
                    { parse_mode: 'Markdown', ...menuPrincipal }
                ).then(() => limparEstado(chatId))
                 .catch(console.error);
            }

            estados[chatId].username = usuarioEncontrado.username;
            confirmarRemocaoUsuario(chatId);
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro ao solicitar usuário:', err);
        limparEstado(chatId);
    });
}

function confirmarRemocaoUsuario(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];

    bot.sendMessage(
        chatId,
        `⚠️ *Confirmar remoção do usuário?*\n\n` +
        `👤 Usuário: \`${username}\`\n` +
        `❗ Esta ação é *irreversível* e removerá todos os dados!`,
        {
            parse_mode: 'Markdown',
            reply_markup: {
                keyboard: [
                    [{ text: '✅ Sim, remover' }],
                    [{ text: '❌ Cancelar' }]
                ],
                resize_keyboard: true,
                one_time_keyboard: true
            }
        }
    ).then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            if (resposta.text?.toLowerCase().includes('remover')) {
                removerUsuarioSSH(chatId);
            } else {
                bot.sendMessage(
                    chatId,
                    '⚠️ Remoção cancelada.',
                    menuPrincipal
                ).catch(console.error);
                limparEstado(chatId);
            }
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    }).catch(err => {
        console.error('Erro na confirmação:', err);
        limparEstado(chatId);
    });
}

async function removerUsuarioSSH(chatId) {
    const { bot, menuPrincipal, username, from_username } = estados[chatId];

    try {
        const ssh = await new ConexaoSSH().conectar();
        
        // Verifica existência do usuário
        const { stdout } = await ssh.execCommand(`id -u ${username} 2>/dev/null || echo "NOT_FOUND"`);
        if (stdout.trim() === "NOT_FOUND") {
            throw new Error(`Usuário "${username}" não encontrado no servidor`);
        }

        // Remove usuário e diretório home
        const { stderr } = await ssh.execCommand(`sudo userdel -r ${username}`);
        ssh.dispose();

        if (stderr && !stderr.includes('not found')) {
            throw new Error(`Erro ao remover: ${stderr}`);
        }

        // Remove do arquivo JSON
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        const usuarioIndex = usuarios.findIndex(u => u.username === username);
        if (usuarioIndex !== -1) {
            usuarios.splice(usuarioIndex, 1);
            fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
        }

        // Notifica sucesso
        await bot.sendMessage(
            chatId,
            `✅ *Usuário removido com sucesso!*\n\n` +
            `👤 \`${username}\` foi completamente removido do sistema.`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // Notifica admin se configurado
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `🗑️ *Usuário Removido*\n\n` +
                `👤 ${username}\n` +
                `👮 Por: @${from_username || 'sistema'}\n` +
                `⏱️ ${new Date().toLocaleString()}`,
                { parse_mode: 'Markdown' }
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao remover usuário:', error);
        await bot.sendMessage(
            chatId,
            `❌ *Falha na remoção!*\n\n` +
            `Erro: ${error.message}\n\n` +
            `Por favor, tente novamente ou contate o suporte.`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        ).catch(console.error);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        // Limpa timeout
        clearTimeout(estados[chatId].timeout);
        
        // Remove listeners
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        
        // Limpa estado
        delete estados[chatId];
    }
}