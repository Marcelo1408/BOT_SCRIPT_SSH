const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosPath = path.join('/root/bot-ssh/data/usuarios.json');
const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    const chatId = msg.chat.id;
    if (!chatId) return;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Finalize ou cancele a anterior.', menuPrincipal);
    }

    estados[chatId] = {
        etapa: 'usuario',
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    solicitarUsuario(bot, chatId);
};

function solicitarUsuario(bot, chatId) {
    bot.sendMessage(chatId, '❌ Digite o nome do usuário que deseja remover:')
        .then(() => {
            const listener = async (res) => {
                if (res.chat.id !== chatId) return;

                const username = res.text.trim().toLowerCase();

                if (!/^[a-z_][a-z0-9_-]{0,31}$/i.test(username)) {
                    await bot.sendMessage(chatId, '❌ Nome inválido! Deve ter entre 1 e 32 caracteres.', estados[chatId].menuPrincipal);
                    return limparEstado(chatId);
                }

                estados[chatId].username = username;

                try {
                    const ssh = await new ConexaoSSH().conectar();
                    const { stdout } = await ssh.execCommand(`id ${username} >/dev/null 2>&1 && echo "EXISTS" || echo "NOT_FOUND"`);
                    if (stdout.includes('NOT_FOUND')) throw new Error('Usuário não encontrado no servidor');

                    // Remove usuário no sistema
                    const { stderr } = await ssh.execCommand(`sudo userdel -r ${username}`);
                    ssh.dispose();

                    if (stderr && !stderr.includes('not found')) throw new Error(stderr);

                    // Remove do JSON local
                    let usuarios = fs.existsSync(usuariosPath) ? JSON.parse(fs.readFileSync(usuariosPath, 'utf8')) : [];
                    usuarios = usuarios.filter(u => u.username !== username);
                    fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

                    await bot.sendMessage(chatId, `✅ Usuário \`${username}\` removido com sucesso.`, { parse_mode: 'Markdown', ...estados[chatId].menuPrincipal });

                    if (process.env.CHAT_ID_ADMIN) {
                        await bot.sendMessage(process.env.CHAT_ID_ADMIN,
                            `🗑️ *Usuário Removido*\n👤 \`${username}\`\n👮 Removido por: @${estados[chatId].from_username || 'desconhecido'}`, { parse_mode: 'Markdown' });
                    }

                } catch (err) {
                    await bot.sendMessage(chatId, `❌ Erro ao remover usuário:\n${err.message}`, estados[chatId].menuPrincipal);
                } finally {
                    limparEstado(chatId);
                }
            };

            estados[chatId].messageListener = listener;
            bot.once('message', listener);
        });
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        estados[chatId].bot.removeListener('message', estados[chatId].messageListener);
        delete estados[chatId];
    }
}
