const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosDir = path.join('/root/bot-ssh/data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Já há uma operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarRemocaoUsuario(bot, chatId, menuPrincipal);
};

function iniciarRemocaoUsuario(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '🗑️ Digite o nome do usuário que deseja REMOVER:')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const username = resposta.text?.trim() || '';
                
                if (!/^[a-z_][a-z0-9_-]{0,31}$/i.test(username)) {
                    bot.sendMessage(chatId, '❌ Nome inválido! Use 1-32 caracteres (letras, números, hífens ou _)', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].username = username.toLowerCase();
                confirmarRemocao(chatId);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar usuário:', err);
            limparEstado(chatId);
        });
}

async function confirmarRemocao(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];
    
    bot.sendMessage(
        chatId,
        `⚠️ *CONFIRMAÇÃO DE REMOÇÃO*\n\n` +
        `Você está prestes a remover o usuário:\n` +
        `👤: \`${username}\`\n\n` +
        `Esta ação é *irreversível*! Todos os dados do usuário serão apagados.\n\n` +
        `Digite "SIM" para confirmar ou qualquer outra coisa para cancelar.`,
        { parse_mode: 'Markdown' }
    )
    .then(() => {
        const listener = (resposta) => {
            if (!estados[chatId] || resposta.chat.id !== chatId) return;

            if (resposta.text?.trim().toLowerCase() === 'sim') {
                removerUsuario(chatId);
            } else {
                bot.sendMessage(chatId, '❌ Operação cancelada. O usuário não foi removido.', menuPrincipal)
                    .then(() => limparEstado(chatId))
                    .catch(console.error);
            }
        };

        estados[chatId].messageListeners.push(listener);
        bot.once('message', listener);
    })
    .catch(err => {
        console.error('Erro ao solicitar confirmação:', err);
        limparEstado(chatId);
    });
}

async function removerUsuario(chatId) {
    const { bot, menuPrincipal, username, from_username } = estados[chatId];
    
    try {
        // 1. Remover do servidor via SSH (com tratamento para mail spool)
        const ssh = await new ConexaoSSH().conectar();
        
        // Primeiro tenta remover normalmente
        let { stderr } = await ssh.execCommand(`sudo userdel -r ${username}`);
        
        // Se encontrar erro de mail spool, tenta remover sem o -r e depois remove manualmente
        if (stderr && stderr.includes('mail spool')) {
            console.log(`Detectado erro de mail spool, tentando abordagem alternativa...`);
            
            // Remove usuário sem remover diretório
            await ssh.execCommand(`sudo userdel ${username}`);
            
            // Remove manualmente o diretório home e mail spool
            await ssh.execCommand(`sudo rm -rf /home/${username}`);
            await ssh.execCommand(`sudo rm -f /var/mail/${username}`);
            
            stderr = ''; // Reset stderr para indicar sucesso
        }

        ssh.dispose();

        if (stderr && !stderr.includes('does not exist')) {
            throw new Error(stderr);
        }

        // 2. Remover do arquivo local
        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }

        const usuarioIndex = usuarios.findIndex(u => u.username === username);
        let usuarioRemovido = null;

        if (usuarioIndex !== -1) {
            usuarioRemovido = usuarios.splice(usuarioIndex, 1)[0];
            fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
        }

        // 3. Enviar confirmação
        const dataFormatada = new Date().toLocaleString('pt-BR');
        let mensagemSucesso = `✅ *Usuário removido com sucesso!*\n\n` +
                             `👤 Nome: \`${username}\`\n` +
                             `⏱️ Remoção: ${dataFormatada}`;

        if (usuarioRemovido) {
            mensagemSucesso += `\n📅 Data de criação: ${new Date(usuarioRemovido.data_criacao).toLocaleDateString('pt-BR')}`;
        } else {
            mensagemSucesso += `\nℹ️ Usuário não encontrado no registro local`;
        }

        await bot.sendMessage(
            chatId,
            mensagemSucesso,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // Notificar admin
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `❌ Usuário removido\n` +
                `👤 ${username}\n` +
                `⏱️ ${dataFormatada}\n` +
                `👤 Por: @${from_username || 'desconhecido'}`
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao remover usuário:', error);
        
        if (error.message.includes('does not exist')) {
            // Usuário não existe no servidor - oferecer para remover do registro local
            estados[chatId].etapa = 'remover_local';
            bot.sendMessage(
                chatId,
                `⚠️ O usuário "${username}" não existe no servidor. Deseja remover do registro local? (sim/não)`,
                { parse_mode: 'Markdown' }
            )
            .then(() => {
                const listener = (resposta) => {
                    if (!estados[chatId] || resposta.chat.id !== chatId) return;

                    if (resposta.text?.trim().toLowerCase() === 'sim') {
                        removerUsuarioLocal(chatId);
                    } else {
                        bot.sendMessage(chatId, 'Operação cancelada. O usuário não foi removido.', menuPrincipal)
                            .then(() => limparEstado(chatId))
                            .catch(console.error);
                    }
                };

                estados[chatId].messageListeners.push(listener);
                bot.once('message', listener);
            })
            .catch(console.error);
        } else {
            await bot.sendMessage(
                chatId,
                `❌ Falha ao remover usuário:\n${error.message}\n\nTente novamente.`,
                menuPrincipal
            ).catch(console.error);
            limparEstado(chatId);
        }
    }
}

async function removerUsuarioLocal(chatId) {
    const { bot, menuPrincipal, username } = estados[chatId];
    
    try {
        if (!fs.existsSync(usuariosPath)) {
            throw new Error('Arquivo de usuários não encontrado');
        }

        const usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        const updatedUsers = usuarios.filter(u => u.username !== username);
        
        if (usuarios.length === updatedUsers.length) {
            await bot.sendMessage(
                chatId,
                `ℹ️ O usuário "${username}" não foi encontrado no registro local.`,
                menuPrincipal
            );
            return;
        }
        
        fs.writeFileSync(usuariosPath, JSON.stringify(updatedUsers, null, 2));
        await bot.sendMessage(
            chatId,
            `✅ "${username}" removido do registro local.`,
            menuPrincipal
        );

    } catch (error) {
        console.error('Erro ao remover do registro local:', error);
        await bot.sendMessage(
            chatId,
            `❌ Erro ao acessar registro local: ${error.message}`,
            menuPrincipal
        );
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        delete estados[chatId];
    }
}