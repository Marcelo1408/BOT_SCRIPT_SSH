require('dotenv').config(); // Adicione esta linha no topo

const fs = require('fs');
const path = require('path');

module.exports = function(bot, msg, menuPrincipal) {
  const chatId = msg.chat.id;
  const revendasDir = path.join('/root/bot-ssh/data');
  const revendasPath = path.join(revendasDir, 'revendas.json');
  
  // Verificação robusta de admin
  const isAdmin = () => {
    try {
      console.log('ADM_ID do .env:', process.env.ADM_ID);
      console.log('ID recebido:', msg.from.id);
      if (!process.env.ADM_ID) {
        console.error('ADM_ID não está definido no .env');
        return false;
      }
      return msg.from.id.toString() === process.env.ADM_ID.toString();
    } catch (err) {
      console.error('Erro na verificação de admin:', err);
      return false;
    }
  };

  if (!isAdmin()) {
    // Log detalhado de tentativa de acesso
    console.warn(
      `[ACESSO NEGADO] Tentativa de acesso não autorizado:\n` +
      `ID: ${msg.from.id}\n` +
      `Nome: ${msg.from.first_name || ''} ${msg.from.last_name || ''}\n` +
      `Username: @${msg.from.username || 'sem username'}\n` +
      `Data/Hora: ${new Date().toLocaleString()}`
    );
    return bot.sendMessage(chatId, '❌ Apenas o administrador pode criar revendas.', menuPrincipal)
      .then(() => {
        console.warn(`Tentativa de acesso não autorizado pelo ID: ${msg.from.id}`);
      });
  }

  // Inicia o processo de criação
  const estados = {};
  estados[chatId] = { etapa: 'nome' };

  bot.sendMessage(chatId, 'Digite o nome da revenda:')
    .then(() => {
      // Listener para o nome
      const nomeListener = (msg) => {
        if (msg.chat.id !== chatId) return;
        
        estados[chatId].nome = msg.text.trim();
        estados[chatId].etapa = 'idTelegram';
        
        bot.removeListener('message', nomeListener);
        bot.sendMessage(chatId, 'Digite o ID do Telegram da revenda:')
          .then(() => {
            // Listener para o ID
            const idListener = (msg) => {
              if (msg.chat.id !== chatId) return;
              
              const idTelegram = msg.text.trim();
              if (!/^\d+$/.test(idTelegram)) {
                bot.removeListener('message', idListener);
                return bot.sendMessage(chatId, '❌ ID do Telegram inválido. Deve conter apenas números.', menuPrincipal);
              }
              
              estados[chatId].idTelegram = idTelegram;
              estados[chatId].etapa = 'credito';
              
              bot.removeListener('message', idListener);
              bot.sendMessage(chatId, 'Digite a quantidade de crédito (usuários que podem ser criados):')
                .then(() => {
                  // Listener para o crédito
                  const creditoListener = (msg) => {
                    if (msg.chat.id !== chatId) return;
                    
                    const credito = parseInt(msg.text.trim());
                    if (isNaN(credito) || credito <= 0) {
                      bot.removeListener('message', creditoListener);
                      return bot.sendMessage(chatId, '❌ Valor inválido. Digite um número positivo.', menuPrincipal);
                    }
                    
                    // Processamento final
                    processarCriacaoRevenda(bot, chatId, estados[chatId], credito, menuPrincipal, revendasPath);
                    bot.removeListener('message', creditoListener);
                  };
                  
                  bot.on('message', creditoListener);
                });
            };
            
            bot.on('message', idListener);
          });
      };
      
      bot.on('message', nomeListener);
    });
};

// Função separada para processar a criação
function processarCriacaoRevenda(bot, chatId, dados, credito, menuPrincipal, revendasPath) {
  try {
    // Carrega revendas existentes
    let revendas = [];
    if (fs.existsSync(revendasPath)) {
      revendas = JSON.parse(fs.readFileSync(revendasPath, 'utf8'));
    }

    // Verifica se revenda já existe
    if (revendas.some(r => r.idTelegram === dados.idTelegram)) {
      return bot.sendMessage(chatId, '❌ Já existe uma revenda com este ID do Telegram.', menuPrincipal);
    }

    // Adiciona nova revenda
    revendas.push({
      id: Date.now().toString(),
      nome: dados.nome,
      idTelegram: dados.idTelegram,
      creditoInicial: credito,
      creditoRestante: credito,
      dataCriacao: new Date().toISOString(),
      dataVencimento: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 dias
    });

    // Salva no arquivo
    fs.writeFileSync(revendasPath, JSON.stringify(revendas, null, 2));

    bot.sendMessage(
      chatId,
      `✅ *Revenda criada com sucesso!*\n\n` +
      `🔖 *Nome:* ${dados.nome}\n` +
      `🆔 *ID Telegram:* ${dados.idTelegram}\n` +
      `💰 *Crédito Inicial:* ${credito} usuários\n` +
      `📅 *Vencimento:* ${new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}`,
      { parse_mode: 'Markdown', ...menuPrincipal }
    );
  } catch (err) {
    console.error('Erro ao criar revenda:', err);
    bot.sendMessage(chatId, '❌ Ocorreu um erro ao criar a revenda.', menuPrincipal);
  }
}