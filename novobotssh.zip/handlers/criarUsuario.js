const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosDir = path.join('/root/bot-ssh/data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

// Garante que o diretório existe
if (!fs.existsSync(usuariosDir)) {
  fs.mkdirSync(usuariosDir, { recursive: true });
}

const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
    if (!msg?.chat?.id) {
        console.error('Mensagem inválida:', msg);
        return;
    }

    const chatId = msg.chat.id;

    if (estados[chatId]) {
        return bot.sendMessage(chatId, '⚠️ Operação em andamento. Complete ou cancele a anterior.', menuPrincipal)
            .catch(console.error);
    }

    estados[chatId] = {
        etapa: 'nome',
        messageListeners: [],
        bot,
        menuPrincipal,
        from_username: msg.from?.username
    };

    iniciarCriacaoUsuario(bot, chatId, menuPrincipal);
};

function iniciarCriacaoUsuario(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '✅ Digite o nome para o usuário (ex: Carlos, Maria, Vovo):')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const username = resposta.text?.trim() || '';
                
                if (username.length < 3 || !/^[a-zA-ZÀ-ÿ\s]+$/.test(username)) {
                    bot.sendMessage(chatId, '❌ Nome inválido. Use apenas letras (mínimo 3 caracteres).\nEx: Carlos, Maria, Vovo', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                // Remove espaços e converte para minúsculas
                estados[chatId].username = username.replace(/\s+/g, '').toLowerCase();
                solicitarSenha(bot, chatId, menuPrincipal);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar nome:', err);
            limparEstado(chatId);
        });
}

function solicitarSenha(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '🔑 Digite a senha (mínimo 4 caracteres):')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const senha = resposta.text?.trim() || '';
                
                if (senha.length < 4) {
                    bot.sendMessage(chatId, '❌ Senha muito curta. Mínimo 4 caracteres.', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].senha = senha;
                solicitarDias(bot, chatId, menuPrincipal);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar senha:', err);
            limparEstado(chatId);
        });
}

function solicitarDias(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '⏳ Quantos dias de acesso? (1-365):')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const dias = parseInt(resposta.text?.trim() || 0);
                
                if (isNaN(dias) || dias < 1 || dias > 365) {
                    bot.sendMessage(chatId, '❌ Valor inválido. Digite um número entre 1 e 365.', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].dias = dias;
                solicitarLimite(bot, chatId, menuPrincipal);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar dias:', err);
            limparEstado(chatId);
        });
}

function solicitarLimite(bot, chatId, menuPrincipal) {
    bot.sendMessage(chatId, '🔢 Limite de conexões simultâneas (1-10):')
        .then(() => {
            const listener = (resposta) => {
                if (!estados[chatId] || resposta.chat.id !== chatId) return;

                const limite = parseInt(resposta.text?.trim() || 0);
                
                if (isNaN(limite) || limite < 1 || limite > 10) {
                    bot.sendMessage(chatId, '❌ Valor inválido. Digite um número entre 1 e 10.', menuPrincipal)
                        .then(() => limparEstado(chatId))
                        .catch(console.error);
                    return;
                }

                estados[chatId].limite = limite;
                criarUsuarioSSH(chatId);
            };

            estados[chatId].messageListeners.push(listener);
            bot.once('message', listener);
        })
        .catch(err => {
            console.error('Erro ao solicitar limite:', err);
            limparEstado(chatId);
        });
}

async function criarUsuarioSSH(chatId) {
    const { bot, menuPrincipal, username, senha, dias, limite, from_username } = estados[chatId];
    
    try {
        // 1. Criar usuário no sistema
        const ssh = await new ConexaoSSH().conectar();
        
        // Verifica se usuário já existe
        const { stdout } = await ssh.execCommand(`id -u ${username} 2>/dev/null`);
        if (stdout.trim()) {
            throw new Error(`Usuário ${username} já existe`);
        }

        // Comandos para criar usuário
        const dataExpiracao = new Date();
        dataExpiracao.setDate(dataExpiracao.getDate() + dias);

        const comandos = [
            `sudo useradd -m -s /bin/bash ${username}`,
            `echo "${username}:${senha}" | sudo chpasswd`,
            `sudo chage -E $(date --date="${dias} days" +%Y-%m-%d) ${username}`,
            `echo "${username} hard maxlogins ${limite}" | sudo tee -a /etc/security/limits.conf`
        ].join(' && ');

        const { stderr } = await ssh.execCommand(comandos);
        if (stderr && !stderr.includes('password updated successfully')) {
            throw new Error(stderr);
        }

        ssh.dispose();

        // 2. Salvar no arquivo JSON
        const usuarioData = {
            username,
            senha,
            data_criacao: new Date().toISOString(),
            expira_em: dataExpiracao.toISOString(),
            limite_conexoes: limite,
            tipo: 'normal'
        };

        let usuarios = [];
        if (fs.existsSync(usuariosPath)) {
            usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
        }
        usuarios.push(usuarioData);
        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        // 3. Enviar confirmação
        const dataFormatada = dataExpiracao.toLocaleString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });

        await bot.sendMessage(
            chatId,
            `✅ *Conta criada com sucesso!*\n\n` +
            `👤 Usuário: \`${username}\`\n` +
            `🔑 Senha: \`${senha}\`\n` +
            `⏳ Validade: ${dias} dias\n` +
            `📅 Expira em: ${dataFormatada}\n` +
            `🔌 Conexões: ${limite} simultâneas`,
            { parse_mode: 'Markdown', ...menuPrincipal }
        );

        // Notificar admin
        if (process.env.CHAT_ID_ADMIN) {
            await bot.sendMessage(
                process.env.CHAT_ID_ADMIN,
                `📝 Nova conta SSH\n` +
                `👤 ${username}\n` +
                `⏳ ${dias} dias\n` +
                `👤 Criado por: @${from_username || 'desconhecido'}`
            ).catch(console.error);
        }

    } catch (error) {
        console.error('Erro ao criar usuário:', error);
        await bot.sendMessage(
            chatId,
            `❌ Falha ao criar conta:\n${error.message}\n\nTente novamente.`,
            menuPrincipal
        ).catch(console.error);
    } finally {
        limparEstado(chatId);
    }
}

function limparEstado(chatId) {
    if (estados[chatId]) {
        estados[chatId].messageListeners.forEach(listener => {
            estados[chatId].bot.removeListener('message', listener);
        });
        delete estados[chatId];
    }
}