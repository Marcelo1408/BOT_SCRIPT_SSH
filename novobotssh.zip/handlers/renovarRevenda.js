const fs = require('fs');
const path = require('path');

module.exports = function(bot, msg, menuPrincipal) {
  const chatId = msg.chat.id;
  const revendasPath = path.join(__dirname, '..', 'data', 'revendas.json');
  
  // Verifica se é admin
  if (msg.from.id.toString() !== process.env.ADM_ID) {
    return bot.sendMessage(chatId, '❌ Apenas o administrador pode renovar revendas.', menuPrincipal);
  }

  const estados = {};
  estados[chatId] = { etapa: 'idTelegram' };

  // Carrega revendas existentes
  const revendas = JSON.parse(fs.readFileSync(revendasPath, 'utf8'));
  
  if (revendas.length === 0) {
    return bot.sendMessage(chatId, '❌ Nenhuma revenda cadastrada.', menuPrincipal);
  }

  // Lista revendas para seleção
  const listaRevendas = revendas.map(r => {
    const expiracao = new Date(r.dataExpiracao).toLocaleDateString();
    return `- ${r.nome} (ID: ${r.idTelegram}) - Expira em: ${expiracao}`;
  }).join('\n');
  
  bot.sendMessage(chatId, `Revendas disponíveis:\n\n${listaRevendas}\n\nDigite o ID do Telegram da revenda que deseja renovar:`);
  
  bot.once('message', (msg) => {
    if (msg.chat.id !== chatId) return;
    
    const idTelegram = msg.text;
    const revenda = revendas.find(r => r.idTelegram === idTelegram);
    
    if (!revenda) {
      return bot.sendMessage(chatId, '❌ Revenda não encontrada.', menuPrincipal);
    }
    
    estados[chatId].revenda = revenda;
    estados[chatId].etapa = 'dias';
    bot.sendMessage(chatId, `Revenda selecionada: ${revenda.nome}\nData atual de expiração: ${new Date(revenda.dataExpiracao).toLocaleDateString()}\n\nDigite a quantidade de dias para renovar:`);
    
    bot.once('message', (msg) => {
      if (msg.chat.id !== chatId) return;
      
      const dias = parseInt(msg.text);
      if (isNaN(dias)) {
        return bot.sendMessage(chatId, '❌ Valor inválido. Digite um número.', menuPrincipal);
      }
      
      // Atualiza a data de expiração
      const dataAtual = revenda.dataExpiracao ? new Date(revenda.dataExpiracao) : new Date();
      dataAtual.setDate(dataAtual.getDate() + dias);
      revenda.dataExpiracao = dataAtual.toISOString();
      
      // Salva no arquivo
      fs.writeFileSync(revendasPath, JSON.stringify(revendas, null, 2));
      
      bot.sendMessage(chatId, `✅ Revenda renovada com sucesso!\n\nRevenda: ${revenda.nome}\nNova data de expiração: ${dataAtual.toLocaleDateString()}`, menuPrincipal);
      delete estados[chatId];
    });
  });
};