const fs = require('fs');
const path = require('path');

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  const filePath = path.join(__dirname, '../data/servidores.json');

  // Verifica se o arquivo existe
  if (!fs.existsSync(filePath)) {
    return bot.sendMessage(chatId, '⚠️ Nenhum servidor cadastrado.', menuPrincipal);
  }

  try {
    // Lê e parseia o arquivo JSON
    const data = fs.readFileSync(filePath, 'utf8');
    const servidores = JSON.parse(data);

    // Verifica se há servidores cadastrados
    if (!servidores || !servidores.length) {
      return bot.sendMessage(chatId, '⚠️ Nenhum servidor cadastrado.', menuPrincipal);
    }

    // Prepara a mensagem de resposta
    let mensagem = '🖥️ *Servidores cadastrados:*\n\n';

    servidores.forEach((srv, i) => {
      // Usando os mesmos nomes de campos do código de cadastro:
      // nome, host (ip), user (usuário), password (senha), port (porta)
      mensagem += `*${i + 1}️⃣ ${srv.nome || 'Sem nome'}*\n` +
                 `🌐 IP: \`${srv.host || srv.ip || 'Não informado'}\`\n` +
                 `👤 Usuário: \`${srv.user || srv.usuario || 'Não informado'}\`\n` +
                 `🔑 Senha: \`${srv.password || srv.senha || 'Não informada'}\`\n` +
                 `📡 Porta: \`${srv.port || srv.porta || '22'}\`\n\n`;
    });

    // Envia a mensagem formatada
    bot.sendMessage(
      chatId, 
      mensagem, 
      { 
        parse_mode: 'Markdown', 
        ...menuPrincipal 
      }
    );

  } catch (err) {
    console.error('Erro ao ler servidores.json:', err);
    bot.sendMessage(
      chatId, 
      '❌ Erro ao acessar a lista de servidores.', 
      menuPrincipal
    );
  }
};