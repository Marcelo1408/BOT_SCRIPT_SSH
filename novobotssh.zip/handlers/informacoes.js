const fs = require('fs');
const path = require('path');

module.exports = () => {
  return async (bot, msg, options = {}) => {
    try {
      const chatId = msg.chat.id;
      await bot.sendChatAction(chatId, 'typing');

      const usuariosPath = path.join(__dirname, '..', 'data', 'usuarios.json');
      const usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));

      if (usuarios.length === 0) {
        return await bot.sendMessage(chatId, '❌ Nenhum usuário cadastrado!', {
          reply_markup: options.reply_markup
        });
      }

      // Função para formatar data
      const formatarData = (dataISO) => {
        if (!dataISO) return 'N/A';
        const data = new Date(dataISO);
        return data.toLocaleDateString('pt-BR');
      };

      // Enviar cada usuário separadamente
      for (let i = 0; i < usuarios.length; i++) {
        const usuario = usuarios[i];
        const dataAtual = new Date();
        const dataExpiracao = new Date(usuario.expira_em);
        const expirado = dataExpiracao < dataAtual;
        const diffTime = dataExpiracao - dataAtual;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 

        let response = '👤 *USUÁRIO SSH*\n\n';
        response += `🔹 *Nome:* ${usuario.username || 'N/A'}\n`;
        response += `🔑 *Senha:* ${usuario.senha || 'N/A'}\n`;
        response += `📶 *Conexões:* ${usuario.limite_conexoes || '0'}\n`;
        
        if (expirado) {
          response += '❌ *Expirado*\n';
        } else {
          response += `⏳ *Expira em:* ${formatarData(usuario.expira_em)} (${diffDays} dias)\n`;
        }
        
        response += `📅 *Criado em:* ${formatarData(usuario.data_criacao)}`;

        // Só coloca o botão Voltar na última mensagem
        const replyMarkup = (i === usuarios.length - 1) ? {
          reply_markup: {
            inline_keyboard: [[{ text: '⬅️ Voltar', callback_data: 'voltar_menu_principal' }]]
          }
        } : {};

        await bot.sendMessage(chatId, response, {
          parse_mode: 'Markdown',
          ...replyMarkup
        });

        // Pequeno delay para não sobrecarregar
        await new Promise(resolve => setTimeout(resolve, 500));
      }

    } catch (error) {
      console.error('Erro no handler de informações:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ocorreu um erro ao listar os usuários.', {
        reply_markup: {
          inline_keyboard: [[{ text: '⬅️ Voltar', callback_data: 'voltar_menu_principal' }]]
        }
      });
    }
  };
};