const fs = require('fs');
const path = require('path');

module.exports = (conexaoSSH) => {
  return (bot, msg, menuPrincipal) => {
    const chatId = msg.chat.id;
    const filePath = path.join(__dirname, '../data/usuarios.json');

    const calcularDias = (dataExpira) => {
      if (!dataExpira) return null;
      const hoje = new Date();
      const expira = new Date(dataExpira);
      if (isNaN(expira)) return null;
      return Math.ceil((expira - hoje) / 86400000);
    };

    if (!fs.existsSync(filePath)) {
      return bot.sendMessage(chatId, '❌ Nenhum usuário cadastrado ainda.', menuPrincipal);
    }

    try {
      const usuarios = JSON.parse(fs.readFileSync(filePath, 'utf8'));

      if (!usuarios?.length) {
        return bot.sendMessage(chatId, '📭 Nenhum usuário cadastrado no sistema.', menuPrincipal);
      }

      let mensagem = '👥 *Usuários Ativos*:\n\n';

      usuarios.forEach(usuario => {
        const diasRestantes = calcularDias(usuario.expira_em); // Corrigido para expira_em

        let validadeMsg = diasRestantes === null ? 'Sem data de validade' :
                         diasRestantes <= 0 ? '⏳ Usuário expirado' :
                         `⏳ Expira em: ${diasRestantes} dia(s)`;

        mensagem += `▫️ *${usuario.username || 'Sem nome'}*\n` + // Corrigido para username
                   `🔑 \`${usuario.senha || 'Sem senha'}\`\n` +
                   `📶 Limite: ${usuario.limite_conexoes || '0'}\n` + // Corrigido para limite_conexoes
                   `${validadeMsg}\n\n`;
      });

      bot.sendMessage(chatId, mensagem, {
        parse_mode: 'Markdown',
        reply_markup: menuPrincipal
      });

    } catch (err) {
      console.error('Erro ao ler arquivo:', err);
      bot.sendMessage(chatId, '❌ Erro ao carregar usuários.', menuPrincipal);
    }
  };
};