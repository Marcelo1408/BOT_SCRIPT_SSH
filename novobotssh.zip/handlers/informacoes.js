const fs = require('fs');
const path = require('path');

module.exports = (conexaoSSH) => {
  return async (bot, msg, menuPrincipal) => {
    const chatId = msg.chat.id;
    const filePath = path.join(__dirname, '../data/usuarios.json');

    const calcularDias = (dataExpira) => {
      if (!dataExpira) return null;
      const hoje = new Date();
      const expira = new Date(dataExpira);
      if (isNaN(expira)) return null;
      return Math.ceil((expira - hoje) / 86400000);
    };

    const formatarData = (dataString) => {
      if (!dataString) return null;
      const data = new Date(dataString);
      return data.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      });
    };

    if (!fs.existsSync(filePath)) {
      return bot.sendMessage(chatId, '❌ Nenhum usuário cadastrado ainda.', menuPrincipal);
    }

    try {
      const usuarios = JSON.parse(fs.readFileSync(filePath, 'utf8'));

      if (!usuarios?.length) {
        return bot.sendMessage(chatId, '📭 Nenhum usuário cadastrado no sistema.', menuPrincipal);
      }

      // Envia mensagem inicial com contagem
      await bot.sendMessage(chatId, `🔍 *${usuarios.length} usuários encontrados:*`, {
        parse_mode: 'Markdown'
      });

      // Envia cada usuário em uma mensagem separada
      for (const usuario of usuarios) {
        const diasRestantes = calcularDias(usuario.expira_em);
        const dataFormatada = formatarData(usuario.expira_em);

        let validadeMsg = diasRestantes === null ? '♾️ *Sem expiração*' :
                         diasRestantes <= 0 ? '❌ *Expirado*' :
                         `⏳ *Expira em:* ${dataFormatada} (${diasRestantes} dias)`;

        const mensagemUsuario = `👤 *USUÁRIO SSH*\n\n` +
                              `🔹 *Nome:* \`${usuario.username || 'N/A'}\`\n` +
                              `🔑 *Senha:* \`${usuario.senha || 'N/A'}\`\n` +
                              `📶 *Conexões:* ${usuario.limite_conexoes || '0'}\n` +
                              `${validadeMsg}\n` +
                              `📅 *Criado em:* ${formatarData(usuario.data_criacao) || 'N/A'}`;

        await bot.sendMessage(chatId, mensagemUsuario, {
          parse_mode: 'Markdown',
          disable_web_page_preview: true
        });

        // Pequeno delay para evitar flood
        await new Promise(resolve => setTimeout(resolve, 300));
      }

      // Envia mensagem final com menu
      await bot.sendMessage(chatId, '✅ Lista de usuários concluída.', menuPrincipal);

    } catch (err) {
      console.error('Erro ao listar usuários:', err);
      await bot.sendMessage(chatId, '❌ Erro ao carregar lista de usuários.', menuPrincipal);
    }
  };
};