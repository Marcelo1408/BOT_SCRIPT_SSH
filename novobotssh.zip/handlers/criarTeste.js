const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');
const cron = require('node-cron');

const usuariosDir = path.join('/root/bot/data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

if (!fs.existsSync(usuariosDir)) {
  fs.mkdirSync(usuariosDir, { recursive: true });
}

const estados = {};

async function limparUsuariosExpirados(bot) {
  try {
    if (!fs.existsSync(usuariosPath)) {
      console.log('Arquivo de usuários não encontrado');
      return;
    }

    const usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
    const agora = new Date();

    const [expirados, ativos] = usuarios.reduce(([exp, atv], usuario) => {
      new Date(usuario.expira_em) <= agora ? exp.push(usuario) : atv.push(usuario);
      return [exp, atv];
    }, [[], []]);

    if (expirados.length === 0) return;

    const ssh = await new ConexaoSSH().conectar();

    await Promise.all(expirados.map(async (usuario) => {
      try {
        await ssh.execCommand(`sudo userdel -r ${usuario.username}`);
        console.log(`Usuário ${usuario.username} removido`);
      } catch (error) {
        console.error(`Erro ao remover ${usuario.username}:`, error.message);
      }
    }));

    ssh.dispose();

    fs.writeFileSync(usuariosPath, JSON.stringify(ativos, null, 2));

    if (bot) {
      const message = `♻️ ${expirados.length} usuários expirados removidos:\n` +
        expirados.map(u => `- ${u.username}`).join('\n');
      bot.sendMessage(process.env.CHAT_ID_ADMIN || 'SEU_CHAT_ID_AQUI', message);
    }

  } catch (error) {
    console.error('Erro na limpeza de usuários:', error);
  }
}

cron.schedule('0 * * * *', () => limparUsuariosExpirados());

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;

  estados[chatId] = { etapa: 'horas' };
  bot.sendMessage(chatId, '⏳ Informe a duração do teste em horas (1-24):');

  bot.once('message', async (resposta) => {
    if (!estados[chatId] || resposta.chat.id !== chatId) return;

    const horas = parseInt(resposta.text, 10);
    if (isNaN(horas) || horas < 1 || horas > 24) {
      bot.sendMessage(chatId, '❌ Duração inválida. Use entre 1 e 24 horas.', menuPrincipal);
      delete estados[chatId];
      return;
    }

    const username = `teste${Math.floor(1000 + Math.random() * 9000)}`;
    const senha = `Teste${Math.floor(1000 + Math.random() * 9000)}!`;

    try {
      const ssh = await new ConexaoSSH().conectar();

      const comando = [
        `sudo useradd -m -s /bin/bash ${username}`,
        `echo "${username}:${senha}" | sudo chpasswd`,
        `sudo chage -E $(date --date="+${horas} hours" +%Y-%m-%d) ${username}`,
        `echo "${username} hard maxlogins 1" | sudo tee -a /etc/security/limits.conf`
      ].join(' && ');

      const result = await ssh.execCommand(comando);
      if (result.stderr) console.error(result.stderr);

      ssh.dispose();

      const usuarioData = {
        username,
        senha,
        data_criacao: new Date().toISOString(),
        expira_em: new Date(Date.now() + horas * 3600000).toISOString(),
        limite_conexoes: 1,
        tipo: 'teste'
      };

      const usuarios = fs.existsSync(usuariosPath) ?
        JSON.parse(fs.readFileSync(usuariosPath, 'utf8')) : [];
      usuarios.push(usuarioData);
      fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

      const dataFormatada = new Date(usuarioData.expira_em).toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });

      bot.sendMessage(
        chatId,
        `🎉 *Conta de teste criada!*\n\n` +
        `👤 Usuário: \`${username}\`\n` +
        `🔑 Senha: \`${senha}\`\n` +
        `⏳ Validade: ${horas} hora(s)\n` +
        `📅 Expira em: ${dataFormatada}\n` +
        `🔌 Limite: 1 conexão\n\n` +
        `⚠️ Esta conta será automaticamente removida após a expiração.`,
        { parse_mode: 'Markdown', ...menuPrincipal }
      );

    } catch (error) {
      console.error('Erro ao criar teste:', error);
      bot.sendMessage(chatId, `❌ Falha ao criar conta de teste:\n${error.message}`, menuPrincipal);
    } finally {
      delete estados[chatId];
    }
  });
};
