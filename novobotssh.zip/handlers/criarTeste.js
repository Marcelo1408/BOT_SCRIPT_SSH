const fs = require('fs');
const path = require('path');
const ConexaoSSH = require('../utils/conexaoSSH');

const usuariosDir = path.join('/root/bot/data');
const usuariosPath = path.join(usuariosDir, 'usuarios.json');

if (!fs.existsSync(usuariosDir)) {
  fs.mkdirSync(usuariosDir, { recursive: true });
}

const estados = {};

module.exports = async (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;

  if (estados[chatId]) {
    return bot.sendMessage(chatId, '⚠️ Uma operação já está em andamento. Finalize-a antes de iniciar outra.', menuPrincipal);
  }

  estados[chatId] = { etapa: 'criacao' };
  
  try {
    // Lê usuários existentes
    let usuarios = [];
    if (fs.existsSync(usuariosPath)) {
      usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
    }
    
    // Gera username aleatório
    const numeroAleatorio = Math.floor(1000 + Math.random() * 9000); // Ex: 1234
    const username = `teste${numeroAleatorio}`;
    const senha = username;
    const horas = 24; // Validade fixa de 1 dia

    const ssh = await new ConexaoSSH().conectar();

    // Data de expiração calculada (1 dia no futuro)
    const dataExpiracao = new Date(Date.now() + 24 * 3600000);
    const dataExpiracaoFormatada = dataExpiracao.toISOString().split('T')[0];

    // Comandos SSH para criar a conta SEM home e bloqueando login
    const comandos = [
      `sudo useradd -M -s /usr/sbin/nologin ${username}`,
      `echo "${username}:${senha}" | sudo chpasswd`,
      `sudo usermod -e ${dataExpiracaoFormatada} ${username}`,
      `echo "${username} hard maxlogins 1" | sudo tee -a /etc/security/limits.conf`,
      `sudo passwd -u ${username}`
    ].join(' && ');

    const { stderr } = await ssh.execCommand(comandos);
    if (stderr && !stderr.includes('password updated successfully')) {
      throw new Error(stderr);
    }

    ssh.dispose();

    // Registro no arquivo JSON
    const usuarioData = {
      username,
      senha,
      data_criacao: new Date().toISOString(),
      expira_em: dataExpiracao.toISOString(),
      limite_conexoes: 1,
      tipo: 'teste',
      status: 'ativo'
    };

    usuarios.push(usuarioData);
    fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

    // Formatando a data para exibição
    const dataFormatada = dataExpiracao.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    await bot.sendMessage(
      chatId,
      `✅ *CONTA DE TESTE CRIADA COM SUCESSO!*\n\n` +
      `👤 Usuário: \`${username}\`\n` +
      `🔑 Senha: \`${senha}\`\n` +
      `⏳ Validade: 1 dia (24 horas)\n` +
      `📅 Expira em: ${dataFormatada}\n\n` +
      `⚠️ Esta conta será automaticamente desativada após a expiração.`,
      { parse_mode: 'Markdown', ...menuPrincipal }
    );

  } catch (error) {
    console.error('Erro ao criar conta de teste:', error);
    bot.sendMessage(chatId, `❌ FALHA AO CRIAR CONTA DE TESTE:\n${error.message}`, menuPrincipal);
  } finally {
    delete estados[chatId];
  }
};

// Função para verificar e bloquear testes expirados
function verificarTestesExpirados() {
  if (!fs.existsSync(usuariosPath)) return;

  const agora = new Date();
  let usuarios = JSON.parse(fs.readFileSync(usuariosPath, 'utf8'));
  let alterado = false;

  usuarios = usuarios.map(user => {
    if (user.tipo === 'teste' && new Date(user.expira_em) <= agora && user.status !== 'bloqueado') {
      alterado = true;
      
      // Bloqueia a conta no sistema também
      const ssh = new ConexaoSSH();
      ssh.conectar().then(() => {
        ssh.execCommand(`sudo usermod -L ${user.username}`);
        ssh.dispose();
      }).catch(console.error);
      
      return { ...user, status: 'bloqueado' };
    }
    return user;
  });

  if (alterado) {
    fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
  }
}

// Verificação inicial e agendamento periódico
verificarTestesExpirados();
setInterval(verificarTestesExpirados, 3600000); // Verifica a cada hora
