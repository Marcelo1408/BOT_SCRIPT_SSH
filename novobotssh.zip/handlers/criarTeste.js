const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');
const cron = require('node-cron');

const estados = {};
const usuariosPath = path.join(__dirname, '../data/usuarios.json');
const usuariosDBPath = '/root/usuarios.db';

// Função para limpar usuários expirados
async function limparUsuariosExpirados(bot) {
  try {
    // Verifica se o arquivo de usuários existe
    if (!fs.existsSync(usuariosPath)) return;

    const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
    const agora = new Date();
    const expirados = usuarios.filter(u => new Date(u.expira_em) <= agora);
    const ativos = usuarios.filter(u => new Date(u.expira_em) > agora);

    if (expirados.length === 0) return;

    const ssh = await conexaoSSH();

    // Remove usuários no servidor
    for (const usuario of expirados) {
      try {
        await ssh.execCommand(`sudo userdel -r ${usuario.username}`);
        console.log(`Usuário ${usuario.username} removido com sucesso`);
      } catch (error) {
        console.error(`Erro ao remover usuário ${usuario.username}:`, error.message);
      }
    }

    ssh.dispose();

    // Atualiza arquivo local
    fs.writeFileSync(usuariosPath, JSON.stringify(ativos, null, 2));

    // Limpa usuários.db se existir
    if (fs.existsSync(usuariosDBPath)) {
      const dbContent = fs.readFileSync(usuariosDBPath, 'utf8');
      const lines = dbContent.split('\n').filter(line => {
        const username = line.split(':')[0];
        return !expirados.some(u => u.username === username);
      });
      fs.writeFileSync(usuariosDBPath, lines.join('\n'));
    }

    // Notifica administradores (opcional)
    if (bot) {
      const message = `♻️ Foram removidos ${expirados.length} usuários expirados:\n` +
        expirados.map(u => `- ${u.username}`).join('\n');
      // Substitua CHAT_ID_ADMIN pelo chat ID do administrador
      bot.sendMessage(CHAT_ID_ADMIN, message);
    }

  } catch (error) {
    console.error('Erro no processo de limpeza:', error);
  }
}

// Agenda limpeza periódica (executa a cada hora)
cron.schedule('0 * * * *', () => limparUsuariosExpirados());

// Executa limpeza na inicialização
limparUsuariosExpirados();

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;

  estados[chatId] = { etapa: 'horas' };
  bot.sendMessage(chatId, '⏳ Informe o tempo de teste (em horas):');

  bot.once('message', (resposta) => {
    if (!estados[chatId] || resposta.chat.id !== chatId) return;

    const horas = parseInt(resposta.text, 10);
    if (isNaN(horas) || horas <= 0) {
      bot.sendMessage(chatId, '❌ Quantidade de horas inválida. Operação cancelada.', menuPrincipal);
      delete estados[chatId];
      return;
    }

    // Gerar usuário e senha aleatórios
    const numero = Math.floor(1000 + Math.random() * 9000);
    const username = `teste${numero}`;
    const senha = username;

    // Data de expiração
    const dataExpiracao = new Date(Date.now() + horas * 3600000);
    const dataFormatada = dataExpiracao.toLocaleString('pt-BR');

    (async () => {
      try {
        const ssh = await conexaoSSH();

        const comando = `
sudo useradd -m -s /bin/bash ${username} &&
echo "${username}:${senha}" | sudo chpasswd &&
echo "${username} hard maxlogins 1" | sudo tee -a /etc/security/limits.conf
        `;

        await ssh.execCommand(comando);
        ssh.dispose();

        // Atualiza os arquivos
        const usuarios = fs.existsSync(usuariosPath)
          ? JSON.parse(fs.readFileSync(usuariosPath))
          : [];

        usuarios.push({
          username: username,
          senha: senha,
          data_criacao: new Date().toISOString(),
          expira_em: dataExpiracao.toISOString(),
          limite_conexoes: 1
        });

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        // Adiciona ao usuarios.db se existir
        if (fs.existsSync(usuariosDBPath)) {
          fs.appendFileSync(usuariosDBPath, `${username}:${senha}\n`);
        }

        bot.sendMessage(
          chatId,
          `🎉 *Teste criado com sucesso!*\n\n` +
          `👤: \`${username}\`\n` +
          `🔑: \`${senha}\`\n` +
          `⏳ Validade: ${horas} horas\n` +
          `📅 Expira em: ${dataFormatada}\n` +
          `🔌 Limite: 1 conexão`,
          { parse_mode: 'Markdown', ...menuPrincipal }
        );

      } catch (error) {
        bot.sendMessage(
          chatId,
          `❌ Falha ao criar teste:\n\n${error.message}`,
          menuPrincipal
        );
      } finally {
        delete estados[chatId];
      }
    })();
  });
};
