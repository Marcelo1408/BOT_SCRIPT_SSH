const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { promisify } = require('util');
const pipeline = promisify(require('stream').pipeline);
const express = require('express');
const multer  = require('multer');

const app = express();

// Configura o Multer para salvar na pasta /root
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, '/root'); // Pasta root da VPS
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); // Mantém o nome original do arquivo
  }
});

const upload = multer({ storage: storage });

module.exports = function(bot, msg, menuPrincipal) {
  const chatId = msg.chat.id;
  const backupDir = '/root'; // <-- Salva diretamente em /root
  
  // Não precisa mais criar a pasta, pois /root já existe e só root pode gravar

  bot.sendMessage(chatId, '📤 Por favor, envie o arquivo de backup (usuarios.json) que deseja carregar para o servidor.');

  const documentHandler = async (docMsg) => {
    if (docMsg.chat.id !== chatId) return;
    
    try {
      if (!docMsg.document) {
        return bot.sendMessage(chatId, '❌ Por favor, envie um arquivo válido.', menuPrincipal);
      }

      if (!docMsg.document.file_name.endsWith('.json')) {
        return bot.sendMessage(chatId, '❌ O arquivo deve ser no formato JSON.', menuPrincipal);
      }

      const fileId = docMsg.document.file_id;
      const fileInfo = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${fileInfo.file_path}`;
      
      const filePath = path.join(backupDir, `backup_${Date.now()}.json`);
      
      // Usando axios para download mais robusto
      const response = await axios({
        method: 'GET',
        url: fileUrl,
        responseType: 'stream'
      });

      const writer = fs.createWriteStream(filePath);
      await pipeline(response.data, writer);

      const nomeArquivo = path.basename(filePath);
      bot.sendMessage(chatId, `✅ Backup carregado com sucesso!\nArquivo salvo como: ${nomeArquivo}`);

    } catch (error) {
      console.error('Erro no upload de backup:', error);
      bot.sendMessage(chatId, '❌ Ocorreu um erro ao processar o backup.', menuPrincipal);
    } finally {
      bot.removeListener('document', documentHandler);
    }
  };

  bot.once('document', documentHandler);
};

app.post('/upload', upload.single('backup'), (req, res) => {
  res.send('Backup enviado e salvo em /root!');
});

app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});